﻿using CodingContest.util;

namespace KCC_Demo.entities
{
    public class KeyValuePair
    {
        public string Key { get; private set; }

        public string Value { get; private set; }

        public KeyValuePair( string[ ] dataAsArray )
        {
            KContract.Requires( dataAsArray != null, "dataAsArray mandatory but is null" );
            KContract.Requires( dataAsArray.Length == 2, "zone record must have 6 fields" );

            Key = dataAsArray[ 0 ];
            Value = dataAsArray[ 1 ];
        }

        public override string ToString( )
        {
            return $"[{Key}] : '{Value}'";
        }
    }
}
