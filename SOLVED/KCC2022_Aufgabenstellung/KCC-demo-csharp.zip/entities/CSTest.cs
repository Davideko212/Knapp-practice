﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KCC_Demo.entities
{
    /// <summary>
    /// Helper class to challenge the compiler
    /// </summary>
    public class CSTest
    {
        public string InitializedPropertyMessage { get; } = "CS6 - Initialized property ok";

        public string LambdaProperty => GetLambda();

        private string interpolation = "String Interpolation ok";

        private string GetLambda()
        {
            return "CS6 - Lamda property ok";
        }

        public CSTest( )
        { }

        public string PatternMatching( object text )
        {
            if( text is string t )
            {
                return t;
            }
            else
            {
                return "Test failed";
            }
        }

        public string StringInterpolation()
        {
            return $"CS7 - {interpolation}";
        }

        public string NullCoalescing( string arg )
        {
            return arg ?? "CS7 - Null Coalescing Operator ok";
        }

        public string OutVariableDeclaration()
        {
            OutVariableDeclarationInteral(out string value);
            return value;
        }

        private void OutVariableDeclarationInteral( out string theValue )
        {
            theValue = "CS7 - Out variable declaration ok";
        }

        public (bool result, string asString) CheckTuple()
        {
            return (true, "CS7 - Tuple check ok");
        }
    }
}
