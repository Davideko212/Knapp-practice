﻿using System;
using System.Diagnostics;

namespace CodingContest.util
{
    /// <summary>
    /// Helper class to assert preconditions in methods
    /// </summary>
    public static class KContract
    {
        /// <summary>
        /// Assert condition and throw ArgumentException when not satisfied
        /// </summary>
        /// <param name="condition">condition to check --> true throws exception</param>
        /// <param name="message">message that is shown</param>
        public static void Requires( bool condition
                                    , string message = "Ungültige Argumente (Requires)"
                                    )
        {
            if ( !condition )
            {
                StackTrace trace = new StackTrace( 1, false );
                StackFrame frame = trace.GetFrame( 0 );
                Type offendingType = frame.GetMethod( ).DeclaringType;
                string methodName = frame.GetMethod( ).Name;

                throw new ArgumentException( $"Methode {offendingType.Name}.{methodName}: " + message );
            }
        }
    }
}
