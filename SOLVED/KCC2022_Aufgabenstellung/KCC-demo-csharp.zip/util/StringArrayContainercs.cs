﻿using System.Text;
using CodingContest.util;

namespace KCC2016_Demo.util
{
    public class StringArrayContainer
    {

        /// <summary>
        /// Returns the stored array
        /// </summary>
        public string[ ] Strings { get; private set; }

        /// <summary>
        /// Get the string at the given array index (0-based)
        /// </summary>
        /// <param name="index">index from which to get the single string</param>
        /// <returns>string</returns>
        public string this[ int index ]
        {
            get
            {
                KContract.Requires( index >=0, "index must be >=0");
                KContract.Requires( index < Strings.Length, "index must be less than the number of strings held" );

                return Strings[ index ];
            }
        }

        /// <summary>
        /// The number of array elements.
        /// </summary>
        public int Count => Strings.Length;

        /// <summary>
        /// Create an instance and store the given string array
        /// </summary>
        /// <param name="data">the string array to store</param>
        public StringArrayContainer( string[ ] data )
        {
            KContract.Requires( data != null, "data is mandatory but is null" );

            this.Strings = data;
        }

        /// <summary>
        /// Get a string representation of the contained strings
        /// </summary>
        /// <returns>stringified content</returns>
        public override string ToString( )
        {
            StringBuilder sb = new StringBuilder( );

            sb.Append( "[" );
            foreach ( string s in Strings )
            {
                if ( sb.Length > 1 )
                {
                    sb.Append( "," );
                }
                sb.Append( "'" ).Append( s ).Append( "'" );
            }
            sb.Append( "]" );

            return sb.ToString( );
        }
    }
}
