﻿using System;
using System.Collections.Generic;
using CodingContest.util;
using KCC_Demo.entities;

namespace KCC_Demo
{
    static class Program
    {
        static void Main()
        {
            try
            {
                System.Console.Out.WriteLine( "###########################################" );
                System.Console.Out.WriteLine( "- KNAPP Coding Contest - Demo Sandbox" );


                CSTest csTest = new CSTest( );
                System.Console.Out.WriteLine( "Showing tests:" );
                System.Console.Out.WriteLine( "   " + csTest.InitializedPropertyMessage );
                System.Console.Out.WriteLine( "   " + csTest.LambdaProperty );
                System.Console.Out.WriteLine( "   " + csTest.PatternMatching( "CS7 - Pattern Matching ok" ) );
                System.Console.Out.WriteLine( "   " + csTest.StringInterpolation() );
                System.Console.Out.WriteLine( "   " + csTest.NullCoalescing( null ) );
                System.Console.Out.WriteLine( "   " + csTest.OutVariableDeclaration() );
                System.Console.Out.WriteLine( "   " + csTest.CheckTuple().asString );
                System.Console.Out.WriteLine( "-------------------------------------------" );
                System.Console.Out.WriteLine( "Showing contents of kvp.csv:" );

                foreach ( KeyValuePair pair in CsvReader.ReadCsvFile<KeyValuePair>( @"input\kvp.csv" ) )
                {
                    System.Console.Out.WriteLine( "   " + pair.ToString( ) );
                }


                System.Console.Out.WriteLine( "-------------------------------------------" );
                System.Console.Out.WriteLine( "" );
                System.Console.Out.WriteLine( "All is well! CU soon!" );
                System.Console.Out.WriteLine( "###########################################" );
            }
            catch ( Exception e )
            {
                ShowException( e, "KNAPP Code" );
            }

            System.Console.Out.WriteLine( "Press <enter>" );
            System.Console.In.ReadLine( );
        }

        private static void ShowException( Exception e, string codeSegment )
        {
            KContract.Requires( e != null, "e is mandatory but is null" );
            KContract.Requires( !string.IsNullOrWhiteSpace( codeSegment ), "codeSegment is mandatory but is null or whitespace" );

            System.Console.Error.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
            System.Console.Error.WriteLine( codeSegment );
            System.Console.Error.WriteLine( "[{0}]: {1}", e.GetType( ).Name, e.ToString( ) );

            if ( e.Data != null && e.Data.Count > 0 )
            {
                System.Console.Error.WriteLine( "Data in exception:" );
                foreach ( KeyValuePair<string, string> elem in e.Data )
                {
                    System.Console.Error.WriteLine( "[{0}] : '{1}'", elem.Key, elem.Value );
                }
            }

            for (Exception inner = e.InnerException
                ; inner != null
                ; inner = inner.InnerException)
            {
                System.Console.WriteLine( ">>[{0}] {1}"
                                                , inner.GetType().Name
                                                , inner.Message
                                            );
            } 

            System.Console.Error.WriteLine( "------------------------------------------------" );

            System.Console.Error.WriteLine( e.StackTrace );

            System.Console.Error.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
        }
    }
}

