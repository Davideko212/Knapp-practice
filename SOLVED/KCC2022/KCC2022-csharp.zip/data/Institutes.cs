﻿
namespace com.knapp.CodingContest.data
{
    public enum Institutes
    {
        // HTl, Schulen ...
        HTBLA_Kaindorf_Sulm
        , HTBLuVA_Pinkafeld
        , HTL_Villach
        , HTL_Rennweg_Wien
        , HTL_Wien_West
        , HTL_Weiz
        , Altes_Gymnasium_Leoben
        , HTL_Bulme_Graz
        , TAC_Hartberg
        , SonsigeSchule
        
        // Uni, FH ...
        , FH_Campus_02
        , FH_Joanneum
        , FH_Technikum_Wien
        , FH_Wr_Neustadt
        , Montanuniversitaet
        , TU_Graz
        , TU_Wien
        , Uni_Goettingen
        , Universitaet_Klagenfurt
        , Universitaet_Wien
        , Sonstige
    }
}
