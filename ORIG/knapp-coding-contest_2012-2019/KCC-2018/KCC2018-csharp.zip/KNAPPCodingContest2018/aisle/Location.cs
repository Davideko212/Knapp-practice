﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.knapp.CodingContest.data;
using com.knapp.CodingContest.warehouse;

namespace com.knapp.CodingContest.aisle
{
    /// <summary>
    /// Represents a space where containers can be stored
    /// </summary>
    public class Location
    {
        /// <summary>
        /// how many containers can be stored one behind another in this location
        /// </summary>
        private readonly int locationDepth;


        /// <summary>
        /// The containers that are stored in this position
        /// </summary>
        private readonly List<Container> containers = new List<Container>();

        /// <summary>
        /// The position within the system where this location can be found
        /// </summary>
        public Position Position { get; private set; }

        /// <summary>
        /// Is the current location the workstation?
        /// </summary>
        /// <returns></returns>
        public virtual bool IsWorkstation()
        {
            return Position.DistanceIntoAisle < 0;
        }


        public Location( Position position, int locationDepth )
        {
            this.Position = position;
            this.locationDepth = locationDepth;
        }

        /// <summary>
        /// Get a collction with the currently stored containers
        /// </summary>
        /// <returns>collection wiht currently stored containers</returns>
        public ReadOnlyCollection<Container> GetContainers()
        {
            return new ReadOnlyCollection<Container>( containers );
        }


        /// <summary>
        /// Return the number of containers that can currently be stored in this location
        /// </summary>
        /// <returns>the number of containers that can be currently stored on this location</returns>
        public int GetRemainingContainerCapacity()
        {
            return locationDepth - containers.Count;
        }

        /// <summary>
        /// Is the container currently reachable on this location
        /// (no other container in front)
        /// </summary>
        /// <param name="container">the container to check</param>
        /// <returns>true if the container is reachable (no other container is in front) false in any other case</returns>
        /// <exception cref="NoSuchContainerAtLocation">If the container to check is currently not stored on the location</exception>
        public bool IsReachable( Container container )
        {
            if( containers.Any() )
            {
                return containers[ 0 ].Equals( container );
            }
            else
            {
                throw new NoSuchContainerAtLocation( "${container} not found at location {this}" );
            }
        }

        /// <summary>
        /// Get the stringified position of the string
        /// </summary>
        /// <returns>stringified position</returns>
        public string GetPositionString()
        {
            if( Position.DistanceIntoAisle < 0 )
            {
                return $"WORKSTATION @ A{Position.Aisle}";
            }
            else
            {
                return Position.ToString();
            }
        }


        /// <summary>
        /// Get a comma seperated list of all containers at the location
        /// </summary>
        private string GetContainerCodes()
        {
            if( containers.Any() )
            {
                return string.Join( ";", containers.Select( ( c ) => c.ContainerCode ) );
            }
            else
            {
                return "<EMPTY>";
            }
        }

        /// <summary>
        /// Get human readable representation
        /// </summary>
        /// <returns>stringified instance</returns>
        public override string ToString()
        {
            return $"Location {GetPositionString()}, containers=[{GetContainerCodes()}]";
        }

        /// <summary>
        /// Is locaion equal to other location
        /// </summary>
        /// <param name="obj">object to compare to</param>
        /// <returns>true if location is same as other location, false in any other case</returns>
        public override bool Equals( object obj )
        {
            if( obj != null && ( obj is Location right ) )
            {
                return this.Position.Equals( right.Position );
            }

            return false;
        }

        /// <summary>
        /// Get hashcode for comparision
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return Position.GetHashCode();
        }


        /// <summary>
        /// USED INTERNALLY
        /// Pulls the first container out of the location
        /// </summary>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException">when currently no container is on this location</exception>
        public Container Pull()
        {
            if( containers.Any() )
            {
                var container = containers[ 0 ];

                containers.RemoveAt( 0 );
                container.CurrentLocation = null;

                return container;
            }
            else
            {
                throw new InvalidOperationException( "No container to pull on location " + ToString() );
            }
        }

        /// <summary>
        /// USED INTERNALLY
        /// Store a container on this location
        /// </summary>
        /// <param name="container">container to store on this location</param>
        /// <exception cref="InvalidOperationException">when the location is already full</exception>
        public void Push( Container container )
        {
            if( containers.Count < locationDepth )
            {
                containers.Insert( 0, container );
                container.CurrentLocation = this;
            }
            else
            {
                throw new InvalidOperationException( "Too many containers at location " + ToString() );
            }
        }
    }
}
