﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace com.knapp.CodingContest.aisle
{
    public class Aisle
    {
        /// <summary>
        /// An aisle can store containers to the left and right of the shuttle
        /// </summary>
        public enum Side {  Left = 0,
                            Right = 1,
                            None = 99 };


        /// <summary>
        /// The number of the aisle
        /// </summary>
        public int AisleNumber { get; private set; }

        /// <summary>
        /// the locations of this aisle
        /// </summary>
        private readonly Location[][] locations;

        /// <summary>
        /// all locations form above as list
        /// </summary>
        private readonly List<Location> locationList = new List<Location>();

        /// <summary>
        /// Create an instance of an aisle
        /// </summary>
        /// <param name="aisleNumber"></param>
        /// <param name="locationCount"></param>
        /// <param name="locationDepth"></param>
        public Aisle( int aisleNumber, int locationCount, int locationDepth )
        {
            this.AisleNumber = aisleNumber;

            locations = new Location[ locationCount ][];

            for( int i = 0; i < locationCount; ++i )
            {
                locations[ i ] = new Location[ 2 ];
                locations[ i ][ ( int ) Side.Left ] = new Location( new Position( aisleNumber, i, Side.Left ), locationDepth );
                locations[ i ][ ( int ) Side.Right ] = new Location( new Position( aisleNumber, i, Side.Right ), locationDepth );

                locationList.Add( locations[ i ][ ( int ) Side.Left ] );
                locationList.Add( locations[ i ][ ( int ) Side.Right ] );
            }
        }

        /// <summary>
        /// Get all locations 
        /// </summary>
        /// <returns></returns>
        public IReadOnlyCollection<Location> GetLocations()
        {
            return new ReadOnlyCollection<Location>( locationList );
        }

        public Location GetLocation( int location, Side side )
        {
            if ( location >= 0 && location < locations.Length )
            {
                return locations[ location ][ ( int ) side ];
            }

            throw new LocationNotFoundException( $"n location found: aisle={AisleNumber}, location={location}, side={side}" );
        }
    }
}
