﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.aisle
{

    /// <summary>
    /// The position describes the exact point in space where a container is stored
    /// </summary>
    public class Position
    {
        /// <summary>
        /// The aisle of this posistion
        /// </summary>
        public int Aisle { get; private set; }

        /// <summary>
        /// The location within the aisle (x-distance)
        /// </summary>
        public int DistanceIntoAisle { get; private set; }

        /// <summary>
        /// The side of the aisle
        /// </summary>
        public Aisle.Side Side { get; private set; }


        /// <summary>
        /// Create an instance of the position
        /// </summary>
        /// <param name="aisle"></param>
        /// <param name="location"></param>
        /// <param name="side"></param>
        public Position( int aisle, int location, Aisle.Side side )
        {
            this.Aisle = aisle;
            this.DistanceIntoAisle = location;
            this.Side = side;
        }

        /// <summary>
        /// Get human readable representation
        /// </summary>
        /// <returns>stringified instance</returns>
        public override string ToString()
        {
            return $"A{Aisle,00}-DIA{DistanceIntoAisle,000}-{Side}";
        }

        
        /// <summary>
        /// Get human readable representation of the position (no side)
        /// </summary>
        /// <returns>stringified instance</returns>
        public string GetPositionString()
        {
            return $"A{Aisle,00}-DIA{DistanceIntoAisle,000}";
        }



        /// <summary>
        /// Check if the position is the same ignoring the side
        /// </summary>
        /// <param name="right">the position to compare to</param>
        /// <returns>true when aisle and DistanceIntoAisle are the same, false in any other case</returns>
        public bool EqualsIgnoreSide( Position right )
        {
            return Aisle == right.Aisle && DistanceIntoAisle == right.DistanceIntoAisle;
        }

        /// <summary>
        /// Is a position equal to another?
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>true if position is the same, false in any other case</returns>
        public override bool Equals( object obj )
        {
            if ( obj != null
                && obj is Position right )
            {
                return this.Aisle == right.Aisle
                            && this.DistanceIntoAisle == right.DistanceIntoAisle
                            && this.Side == right.Side
                            ;
            }

            return false;
        }

        /// <summary>
        /// Get the hash for the location
        /// </summary>
        /// <returns>the hashcode for this location</returns>
        public override int GetHashCode()
        {
            return Aisle * 100000 
                    + DistanceIntoAisle * 10 
                    + Side == aisle.Aisle.Side.Left ? 1 : 2;
        }
    }
}
