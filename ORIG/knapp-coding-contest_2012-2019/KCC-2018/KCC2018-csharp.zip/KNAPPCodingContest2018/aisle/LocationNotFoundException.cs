﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.aisle
{
    [Serializable]
    internal class LocationNotFoundException : Exception
    {
        public LocationNotFoundException()
            : base()
        { /*** empy ***/ }

        public LocationNotFoundException( string message ) : base( message )
        { /*** empy ***/ }

        public LocationNotFoundException( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected LocationNotFoundException( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}
