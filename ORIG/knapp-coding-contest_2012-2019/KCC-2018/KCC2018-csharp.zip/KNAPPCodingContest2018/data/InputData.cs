﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using com.knapp.CodingContest.aisle;
using com.knapp.CodingContest.data;
using com.knapp.CodingContest.util;
using com.knapp.CodingContest.warehouse;
using com.knapp.KCC2017.util;

namespace com.knapp.CodingContest
{
    /// <summary>
    /// Container class for all input into the solution
    /// </summary>
    public class InputData
    {
        /// <summary>
        /// List of all containers (storage and workstation) 
        /// </summary>
        private readonly List<Container> containers = new List<Container>();

        /// <summary>
        /// List of all orders to fulfill
        /// !! Must be fulfilled in sequence!!
        /// </summary>
        private readonly List<Order> orders = new List<Order>();

        /// <summary>
        /// The aisles in the system
        /// </summary>
        public Aisle[] Aisles { get; private set; }

        /// <summary>
        /// Get a read-only collection of all containes (storage and workstation)
        /// </summary>
        /// <returns>read-onyl collection of all containers</returns>
        public ReadOnlyCollection<Container> GetContainers() => new ReadOnlyCollection<Container>( containers );


        /// <summary>
        /// Get a read-only collection of the orders that must be fullfilled (picked)
        /// !!they must be fullfilled in sequence
        /// </summary>
        /// <returns>read-only collection of all orders</returns>
        public ReadOnlyCollection<Order> GetOrders() => new ReadOnlyCollection<Order>( orders );


        /// <summary>
        /// Get the warehouse characteristics
        /// </summary>
        public WarehouseCharacteristics Characteristics { get; private set; }


        /// <summary>
        /// Create from outside only via CreateFromCsv
        /// </summary>
        private InputData()
        {/* EMPTY */  }

        /// <summary>
        /// Load all input data from the csv files and create instance (and composite instances)
        /// </summary>
        /// <returns>a newly created ínstance of the inout</returns>
        public static InputData Load()
        {
            InputData input = new InputData();

            input.LoadWarehouseCharacteristics( System.IO.Path.Combine( Settings.DataPath, Settings.InWarehouseCharacteristics ) );

            input.BuildWarehouse();

            input.LoadContainersFromCsv( System.IO.Path.Combine( Settings.DataPath, Settings.InContainerFilename ) );

            input.LoadOrdersFromCsv( System.IO.Path.Combine( Settings.DataPath, Settings.InOrderFilename ) );

            return input;
        }

        private void LoadWarehouseCharacteristics( string fullFilename )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "filename mandatory but is null or whitespace" );

            JavaPropertyFile properties = new JavaPropertyFile( fullFilename );
            properties.Load();

            Characteristics = new WarehouseCharacteristics( properties );

            System.Console.Out.WriteLine( "+++ loaded: characteristics" );
        }

        /// <summary>
        /// Create the topology of the warehouse
        /// </summary>
        private void BuildWarehouse()
        {
            Aisles = new Aisle[ Characteristics.NumberOfAisles ];

            for ( int i = 0; i < Characteristics.NumberOfAisles; ++i )
            {
                Aisles[ i ] = new Aisle( i, Characteristics.NumberOfPositionsPerAisle, Characteristics.LocationDepth );
            }
        }

        /// <summary>
        /// Load all containers from csv
        /// Format of csv:
        /// # code;product-code;quantity;ia;il;side;_d;
        /// C00000001;PROD000001;10;0;1;98;Left;1;
        /// </summary>
        /// <param name="fullFilename">full path of the csv</param>
        private void LoadContainersFromCsv( string fullFilename )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "fullFilename mandatory but is null or whitespace" );

            using ( StreamReader streamReader = new StreamReader( fullFilename ) )
            {
                string line;
                while ( ( line = streamReader.ReadLine() ) != null )
                {
                    if ( !string.IsNullOrWhiteSpace( line )
                        && !line.StartsWith( "#" ) )
                    {
                        string[] fields = line.Split( new[] { ';' } );

                        string containerCode = fields[ 0 ].Trim();

                        Container container = new Container( containerCode );

                        string productCode = fields[ 1 ].Trim();
                        string quantityAsString = fields[ 2 ].Trim();

                        if ( !string.IsNullOrWhiteSpace( productCode ) )
                        {
                            container.ProductCode = productCode;
                            container.Quantity = int.Parse( quantityAsString );
                        }

                        int aisle = int.Parse( fields[ 3 ]);
                        int location = int.Parse( fields[ 5 ] );
                        Aisle.Side side = (Aisle.Side)Enum.Parse( typeof( Aisle.Side ), fields[ 6 ] );

                        GetLocation( aisle, location, side ).Push( container );

                        if( container.CurrentLocation is null )
                        {
                            throw new InvalidDataException( "WTF???" );
                        }

                        containers.Add( container );
                    }
                }
            }

            System.Console.Out.WriteLine( "+++ loaded: {0} containers", containers.Count );
        }

        public void LoadOrdersFromCsv( string fullFilename )
        {
            KContract.Assert( !string.IsNullOrEmpty( fullFilename ), "fullFilename is mandatory but is null or empty" );
            using ( StreamReader streamReader = new StreamReader( fullFilename ) )
            {
                string line;
                while ( ( line = streamReader.ReadLine() ) != null )
                {
                    if ( !string.IsNullOrWhiteSpace( line )
                        && !line.StartsWith( "#" ) )
                    {
                        string[] fields = line.Split( new[] { ';' } );

                        var order = new Order( fields[ 0 ].Trim(), fields[ 1 ].Trim(), int.Parse( fields[ 2 ] ) );
                        orders.Add( order );
                    }
                }
                System.Console.Out.WriteLine( "+++ loaded: {0} orders", orders.Count );
            }
        }
        /// <summary>
        /// Helper to get a location
        /// </summary>
        /// <param name="aisleNumber"></param>
        /// <param name="location"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        private Location GetLocation( int aisleNumber, int location, Aisle.Side side )
        {
            if ( aisleNumber >= 0 && aisleNumber < Aisles.Length )
            {
                return Aisles[ aisleNumber ].GetLocation( location, side );
            }

            throw new LocationNotFoundException( "invalid aisle: " + aisleNumber );
        }
    }
}
