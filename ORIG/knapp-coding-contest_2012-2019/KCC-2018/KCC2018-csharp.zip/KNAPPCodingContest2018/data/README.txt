Alle Daten f�r die Aufgabenstellung
