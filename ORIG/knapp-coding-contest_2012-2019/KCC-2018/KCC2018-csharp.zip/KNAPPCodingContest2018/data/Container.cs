﻿using System;
using System.Text;
using com.knapp.CodingContest.aisle;

namespace com.knapp.CodingContest.data
{
    public class Container
    {
        /// <summary>
        /// Container code (it's unique name)
        /// </summary>
        public string ContainerCode { get; private set; }

        /// <summary>
        /// Code of the product in the container, null if none
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// Quantity of products in container
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The current location of the container.
        /// !!Null when currently loaded on a shuttle
        /// </summary>
        public Location CurrentLocation { get; set; }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="containerCode">code of this container</param>
        public Container( string containerCode )
        {
            this.ContainerCode = containerCode;
        }


        /// <summary>
        /// Is container empty (all slots are empty)
        /// </summary>
        /// <returns>true container is empty, false in any other case</returns>
        public bool IsEmpy()
        {
            return Quantity <= 0;
        }

        /// <summary>
        /// Stringify this
        /// </summary>
        /// <returns>a human readable string representing this instance</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append( "Container[ containerCode= " ).Append( ContainerCode );
            sb.Append( ", productCode= " ).Append( ProductCode ?? "<EMPTY>" );
            sb.Append( ", quantity= ").Append(Quantity);
            sb.Append( ", location= " ).Append(CurrentLocation?.ToString() ?? "<NONE>");
            sb.Append( "] {" );

            return sb.ToString();
        }


        /// <summary>
        /// Is this container empty?
        /// </summary>
        public bool Empty => Quantity <= 0;

        /// <summary>
        /// Are two containers equal
        /// </summary>
        /// <param name="obj">the container to compare to</param>
        /// <returns>true when the containers are identical, false in any other case</returns>
        public override bool Equals( object obj )
        {
            if( obj != null 
                && obj is Container right )
            {
                return ContainerCode.Equals( right.ContainerCode );
            }

            return false;
        }

        /// <summary>
        /// Get hashcode for this instance
        /// </summary>
        /// <returns>hashcode for this instanc</returns>
        public override int GetHashCode()
        {
            return ContainerCode.GetHashCode();
        }

        /// <summary>
        /// Pick a certain number of items from this container
        /// When the quantity readches 0, the product is set to null
        /// </summary>
        /// <param name="quantity">the number of pieces to take</param>
        /// <exception cref="InvalidOperationException">when more are taken than are in the box</exception>
        internal void Take( int quantity )
        {
            if( quantity > Quantity )
            {
                throw new InvalidOperationException($"Cannot take {quantity} pcs from {ToString()}");
            }

            Quantity -= quantity;   

            if( Quantity == 0 )
            {
                ProductCode = null;
            }
        }
    }
}
