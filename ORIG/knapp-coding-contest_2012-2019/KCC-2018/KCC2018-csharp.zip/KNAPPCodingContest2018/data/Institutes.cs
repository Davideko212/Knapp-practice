﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.data
{
    public enum Institutes
    {
        Altes_Gymnasium_Leoben, //
        FH_Campus_02, //
        FH_Joanneum, //
        FH_Technikum_Wien, //
        FH_Wr_Neustadt, //
        HTL_Bulme_Graz, //
        HTL_Kaindorf, //
        HTL_Pinkafeld, //
        HTL_Rennweg, //
        HTL_Villach, //
        HTL_Weiz, //
        Montanuniversitaet, //
        TU_Graz, //
        TU_Wien, //
        Uni_Goettingen, //
        Universitaet_Klagenfurt, //
        Universitaet_Wien, //
        SonstigeSchule,
        Sonstige, //
      }
}
