﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.knapp.CodingContest.util;
using com.knapp.CodingContest.warehouse;

namespace com.knapp.CodingContest.data
{
    /// <summary>
    /// An order is the entity that is picked at the workstation
    /// and then later on shipped to the customer
    /// </summary>
    public class Order
    {
        /// <summary>
        /// Unique identifier of the order
        /// </summary>
        public string OrderCode { get; private set; }

        /// <summary>
        /// Identifier of the single product needed for this order
        /// </summary>
        public string ProductCode { get; private set; }

        /// <summary>
        /// Original quantity that has been requested by the customer
        /// </summary>
        public int RequestedQuantity { get; private set; }

        /// <summary>
        /// Quantity that is still needed for the order
        /// </summary>
        public int RemainingQuantity { get; private set; }

        /// <summary>
        /// Ctor for an order. An order always has a product
        /// </summary>
        /// <param name="orderCode">unique identifier of the order</param>
        /// <param name="productCode">identifier of the single product needed for this order</param>
        /// <param name="requestedQuantity">Original quantity that has been requested by the customer</param>
        public Order( string orderCode, string productCode, int requestedQuantity )
        {
            KContract.AssertNotNullOrWhitespace( orderCode, nameof( orderCode ) );
            KContract.AssertNotNullOrWhitespace( productCode, nameof( productCode ) );

            OrderCode = orderCode;
            ProductCode = productCode;
            RequestedQuantity = requestedQuantity;
            RemainingQuantity = requestedQuantity;
        }

        ///TODO
        /// <summary>
        /// Pick a number of items, that is add them to the order
        /// </summary>
        /// <param name="ProductCode"></param>
        /// <param name="quantity">the number of items picked, that is moved to this order</param>
        /// <exception cref="InvalidOperationException">when more items are picked than remaining</exception>
        /// <exception cref="ProductMismatchExcpetion">when the picked product is not needed within the order</exception>
        public void Pick( string productCodePicked, int quantity )
        {
            KContract.AssertNotNullOrWhitespace(productCodePicked, "productCodePicked must not be null or whitespace");

            if( productCodePicked != ProductCode )
            {
                throw new ProductMismatchExcpetion( ProductCode, productCodePicked );
            }

            if ( ( RemainingQuantity - quantity ) < 0 )
            {
                throw new InvalidOperationException( $"Can't pick #{quantity}, too much for {this}" );
            }

            RemainingQuantity -= quantity;
        }

        /// <summary>
        /// Are there still items needed to fullfill this order
        /// </summary>
        /// <returns></returns>
        public bool HasRemainingItems()
        {
            return RemainingQuantity > 0;
        }

        /// <summary>
        /// Get human readable string representation of this order
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Order# {OrderCode} {{ProductCode={ProductCode}, RequestedQuantity={RequestedQuantity}, RemainingQuantity={RemainingQuantity}}}";
        }
    }
}
