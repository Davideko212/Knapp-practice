﻿using System;
using System.Collections.Generic;
using System.IO;
using com.knapp.CodingContest.warehouse;
using com.knapp.CodingContest.util;
using com.knapp.KCC2018.solution;

namespace com.knapp.CodingContest
{
    static class Program
    {
        static void Main( )
        {
            Console.Out.WriteLine("KNAPP Coding Contest 2018: Starting...");

            Warehouse warehouse = null;

            try
            {
                Console.Out.WriteLine("#... LOADING DATA ...");
                InputData input = InputData.Load( );

                warehouse = new Warehouse( input );

                Console.Out.WriteLine( "#... DATA LOADED" );
            }
            catch ( Exception e )
            {
                ShowException( e, "Exception in startup code" );
                Console.Out.WriteLine( "Press <enter>" );
                Console.In.ReadLine( );
                throw;
            }

            Console.Out.WriteLine( "# optimization" );
            Console.Out.WriteLine( "### Your output starts here" );

            Solution solution = new Solution( warehouse );

            WriteProperties( solution, Settings.outPropertyFilename );

            solution.RunWarehouseOperations();

            Console.Out.WriteLine( "### Your output stops here" );

            Console.Out.WriteLine( "--> Total operation cost        : {0,10}", warehouse.CurrentOperationsCost );
            Console.Out.WriteLine( "--> Total unfinished order cost : {0,10}", warehouse.CurrentUnfinishedOrderCost );
            Console.Out.WriteLine( "--> Total cleanup cost          : {0,10}", warehouse.CurrentCleanUpCost );
            Console.Out.WriteLine( "                                  ------------" );
            Console.Out.WriteLine( "==> TOTAL COST                  : {0,10}", warehouse.CurrentTotalCost );
            Console.Out.WriteLine( "                                  ============" );

            try
            {
                PrepareUpload.WriteResult( warehouse.GetResult() );
                PrepareUpload.CreateZipFile();
                Console.Out.WriteLine( ">>> Created " + Settings.outZipFilename );
            }
            catch ( Exception e )
            {
                ShowException( e, "Exception in shutdown code" );
                throw;
            }

            Console.Out.WriteLine( "Press <enter>" );
            Console.In.ReadLine( );
        }


        /// <summary>
        /// Helper function to write the properties to the file
        /// </summary>
        /// <param name="solution"></param>
        /// <param name="outFilename"></param>
        /// <exception cref="ArgumentException">when either solution.InstituteId or solution.ParticipantName is not valid</exception>
        private static void WriteProperties(Solution solution, string outFilename)
        {
            KContract.Requires<ArgumentException>( !string.IsNullOrWhiteSpace( solution.ParticipantName ), "solution.ParticipantName must not be empty - please set to correct value" );

            if (File.Exists(outFilename))
            {
                File.Delete( outFilename);
            }

            using ( StreamWriter stream = new StreamWriter( outFilename, false, System.Text.Encoding.GetEncoding( "ISO-8859-1" ) ) )
            {
                stream.WriteLine( "# -*- conf-javaprop -*-" );
                stream.WriteLine( "participant = {0}", solution.ParticipantName );
                stream.WriteLine( "institution = {0}", solution.Institute );
                stream.WriteLine( "technology = c#" );
            }

        }

        /// <summary>
        /// write exception to console.error
        /// includes inner exception and data
        /// </summary>
        /// <param name="e">exception that should be shown</param>
        /// <param name="codeSegment">segment where the exception was caught</param>
        public static void ShowException( Exception e, string codeSegment )
        {
            KContract.Requires( e != null, "e is mandatory but is null" );
            KContract.Requires( ! string.IsNullOrWhiteSpace(codeSegment), "codeSegment is mandatory but is null or whitespace" );

            Console.Out.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
            Console.Out.WriteLine(  codeSegment );
            Console.Out.WriteLine( "[{0}]: {1}", e.GetType( ).Name, e.Message );

            for ( Exception inner = e.InnerException
                ; inner != null
                ; inner = inner.InnerException )
            {
                System.Console.WriteLine( ">>[{0}] {1}"
                                                , inner.GetType( ).Name
                                                , inner.Message
                                            );
            }


            if ( e.Data != null && e.Data.Count > 0 )
            {
                Console.Error.WriteLine( "------------------------------------------------" );
                Console.Error.WriteLine( "Data in exception:" );
                foreach( KeyValuePair<string, string> elem in e.Data )
                {
                    Console.Error.WriteLine( "[{0}] : '{1}'", elem.Key, elem.Value );
                }
            }
            Console.Out.WriteLine( "------------------------------------------------" );
            Console.Out.WriteLine( e.StackTrace );
            Console.Out.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
        }
    }
}
