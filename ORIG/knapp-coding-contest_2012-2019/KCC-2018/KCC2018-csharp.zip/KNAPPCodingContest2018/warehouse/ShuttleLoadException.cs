﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.warehouse
{
    [Serializable]
    internal class ShuttleLoadException : Exception
    {
        public ShuttleLoadException()
            : base()
        { /*** empy ***/ }

        public ShuttleLoadException( string message ) : base( message )
        { /*** empy ***/ }

        public ShuttleLoadException( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected ShuttleLoadException( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}
