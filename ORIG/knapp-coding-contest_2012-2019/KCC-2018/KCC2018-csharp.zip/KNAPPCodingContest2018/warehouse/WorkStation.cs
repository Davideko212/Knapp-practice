﻿using System;
using System.Collections.Generic;
using com.knapp.CodingContest.aisle;
using com.knapp.CodingContest.data;
using com.knapp.CodingContest.util;

namespace com.knapp.CodingContest.warehouse
{
    public class WorkStation : aisle.Position
    {
        /// <summary>
        /// The surrounding warehouse
        /// </summary>
        private readonly Warehouse warehouse;

        /// <summary>
        /// My own store of order to check the sequence
        /// </summary>
        private readonly IList<data.Order> expectedOrders;

        /// <summary>
        /// which order is the next?
        /// </summary>
        private int expectedOrderIndex = 0;

        /// <summary>
        /// The shuttle currently at the workstation, null if none is here
        /// </summary>
        public Shuttle CurrentShuttle { get; set; } = null;

        /// <summary>
        /// Create a workstation
        /// </summary>
        /// <param name="warehouse">the surrounding warehouse</param>
        /// <param name="aisle">the aisle in front of which this pickstation is located</param>
        public WorkStation( Warehouse warehouse, int aisle )
            : base( aisle, -2, CodingContest.aisle.Aisle.Side.None )
        {
            this.warehouse = warehouse;
            this.expectedOrders = warehouse.GetOrders();
        }

        /// <summary>
        /// pick all possible pieces for the given order
        /// picked quantity is Min( order.RemainingQuantity, container.Quantity)
        /// </summary>
        /// <param name="order">the order to pick</param>
        /// <exception cref="ShuttleNotAtLocationException">when not shuttle is at the pickstation</exception>
        /// <exception cref="InvalidOperationException">when the shuttle has no container loaded</exception>
        /// <exception cref="ProductMismatchExcpetion">when the product on the container is not the one needed for this order</exception>
        /// <exception cref="UnexpectedOrderException">when the picked order is not the expected one</exception>
        public void PickOrder( Order order )
        {
            KContract.Assert( order != null, "order mandatory but is null" );

            if( CurrentShuttle == null )
            {
                throw new ShuttleNotAtLocationException("no shuttle at " + ToString() );
            }

            if( CurrentShuttle.LoadedContainer == null )
            {
                throw new InvalidOperationException( "Cannot pick, shuttle has no container loaded ad " + ToString() );
            }

            if( ! order.ProductCode.Equals( CurrentShuttle.LoadedContainer.ProductCode ) )
            {
                throw new ProductMismatchExcpetion( order.ProductCode, CurrentShuttle.LoadedContainer.ProductCode );
            }

            if( !order.OrderCode.Equals( expectedOrders[expectedOrderIndex].OrderCode ) )
            {
                throw new UnexpectedOrderException( order, expectedOrders[ expectedOrderIndex ] );
            }

            int quantity = Math.Min( order.RemainingQuantity, CurrentShuttle.LoadedContainer.Quantity );

            warehouse.WarehouseOperations.PickOrder( order, order.ProductCode, quantity );
            order.Pick( CurrentShuttle.LoadedContainer.ProductCode, quantity );
            CurrentShuttle.LoadedContainer.Take( quantity );

            if( ! order.HasRemainingItems() )
            {
                ++expectedOrderIndex;
            }
        }

        /// <summary>
        /// Get human readable representation
        /// </summary>
        /// <returns>stringified instance</returns>
        public override string ToString()
        {
            return $"WorkStation@ {base.ToString()} {{shuttlePresent: {CurrentShuttle != null }}}";
        }
    }
}
