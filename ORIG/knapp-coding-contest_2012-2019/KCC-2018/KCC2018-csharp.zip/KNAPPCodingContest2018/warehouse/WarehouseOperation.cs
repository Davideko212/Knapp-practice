﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using com.knapp.CodingContest.aisle;
using com.knapp.CodingContest.data;

namespace com.knapp.CodingContest.warehouse
{
    public class WarehouseOperations
    {
        /// <summary>
        /// Definition of the costs of operations
        /// Note: Manipulating them here won't improve your results.
        /// The final cost is calculated on the server :-)
        /// </summary>
        public struct Costs
        {
            public const int MovePerLocation = 1;
            public const int MovePerAisle = 50 * MovePerLocation;
            public const int LoadStore = 10 * MovePerLocation;
            public const int PickOrder = 0;
            public const int UnfinishedOrder = 5000;
        };

        /// <summary>
        /// store for all operations
        /// </summary>
        private readonly List<WarehouseOperation> operations = new List<WarehouseOperation>();

        /// <summary>
        /// The surrounding warehouse
        /// </summary>
        private readonly Warehouse warehouse;

        /// <summary>
        /// The sum of all moves, load, stores and picks already done
        /// </summary>
        public int CurrentOperationsCost { get; private set; } = 0;

        /// <summary>
        /// Get the current total cost, including penalty for unfinished orders and cleanup
        /// </summary>
        public int CurrentTotalCost => CurrentOperationsCost + CalculateUnfinishedOrderCost() + CalculateCleanUpCost();


        /// <summary>
        /// Get all stored operations
        /// </summary>
        /// <returns>read-only collection of all current operations</returns>
        public ReadOnlyCollection<WarehouseOperation> GetOperations() => operations.AsReadOnly();


        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="warehouse">the surrounding warehouse</param>
        public WarehouseOperations( Warehouse warehouse )
        {
            this.warehouse = warehouse;
        }


        /// <summary>
        /// Calculate the cost penalty for all unfinished orders
        /// That is all orders that have HasRemainingItems() == true
        /// </summary>
        /// <returns>the sum of the costs for unfinished orders</returns>
        public int CalculateUnfinishedOrderCost()
        {
            int totalCost = 0;
            foreach( var order in warehouse.GetOrders() )
            {
                if ( order.HasRemainingItems() )
                {
                    totalCost += Costs.UnfinishedOrder;
                }
            }

            return totalCost;
        }

        /// <summary>
        /// Calculate the cost for cleaning up
        /// When done, the shuttle must be empty (no container loaded)
        /// </summary>
        /// <returns>the penalty for not having cleaned up</returns>
        public int CalculateCleanUpCost()
        {
            return warehouse.Shuttle?.LoadedContainer == null ? 0 : Costs.UnfinishedOrder;
        }


        /// <summary>
        /// KNAPP INTERNAL
        /// do all things necessary for a shuttle move
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public void MoveShuttle( Position from, Position to )
        {
            Add( new WarehouseOperation.MoveShuttle( from, to ) );
        }

        /// <summary>
        /// KNAPP INTERNAL
        /// do all things necessary for a container load
        /// </summary>
        /// <param name="side"></param>
        public void LoadContainer( Aisle.Side side )
        {
            Add( new WarehouseOperation.LoadContainer( side ) );
        }


        /// <summary>
        /// KNAPP INTERNAL
        /// do all things necessary for a container store
        /// </summary>
        /// <param name="side"></param>
        public void StoreContainer( Aisle.Side side )
        {
            Add( new WarehouseOperation.StoreContainer( side ) );
        }

        /// <summary>
        /// KNAPP INTERNAL 
        /// do all things necessary for an order pick
        /// </summary>
        /// <param name="order"></param>
        /// <param name="productCode"></param>
        /// <param name="quantity"></param>
        public void PickOrder( Order order, string productCode, int quantity )
        {
            Add( new WarehouseOperation.PickOrder( order, productCode, quantity ) );
        }

        /// <summary>
        /// Add an operation to the operation history
        /// </summary>
        /// <param name="operation"></param>
        private void Add( WarehouseOperation operation )
        {
            CurrentOperationsCost += operation.CalculateCost();
            operations.Add( operation );
        }

    }

    /// <summary>
    /// KNAPP INTERNAL
    /// Base class for all operations carried out during optimization
    /// as get, move, store
    /// </summary>
    public abstract class WarehouseOperation
    {
        private readonly string resultString;

        /// <summary>
        /// Create instance with given data
        /// </summary>
        /// <param name="args">data of operation as object array</param>
        protected WarehouseOperation( params object[] args )
        {
            StringBuilder sb = new StringBuilder();

            sb.Append( GetType().Name ).Append( ";" );

            foreach ( var arg in args )
            {
                sb.Append( arg.ToString() ).Append( ";" );
            }

            resultString = sb.ToString();
        }

        public override string ToString()
        {
            return resultString;
        }

        public string ToResultString()
        {
            return resultString;
        }


        public abstract int CalculateCost();

        /// <summary>
        /// Representation of a shuttle move
        /// </summary>
        internal class MoveShuttle : WarehouseOperation
        {

            public Position From { get; private set; }

            public Position To { get; private set; }

            public MoveShuttle( Position from, Position to )
                : base( from.Aisle, from.DistanceIntoAisle, to.Aisle, to.DistanceIntoAisle )
            {
                From = from;
                To = to;
            }

            public override int CalculateCost()
            {
                return CalculateCost( From, To );
            }

            public static int CalculateCost( Position From, Position To )
            {
                if( From.EqualsIgnoreSide( To ) )
                {
                    return 0;
                }
                else if ( From.Aisle == To.Aisle )
                {
                    return WarehouseOperations.Costs.MovePerLocation
                            + Math.Abs( From.DistanceIntoAisle - To.DistanceIntoAisle ) * WarehouseOperations.Costs.MovePerLocation;
                }
                else
                {
                    return WarehouseOperations.Costs.MovePerLocation
                            + ( From.DistanceIntoAisle + 1 ) * WarehouseOperations.Costs.MovePerLocation
                            + Math.Abs( From.Aisle - To.Aisle ) * WarehouseOperations.Costs.MovePerAisle
                            + ( To.DistanceIntoAisle + 1 )* WarehouseOperations.Costs.MovePerLocation
                            ;
                }
            }
        }

        /// <summary>
        /// Representation of a load container
        /// </summary>
        internal class LoadContainer : WarehouseOperation
        {
            public Aisle.Side Side { get; private set; }

            public LoadContainer( Aisle.Side side )
                : base( side )
            {
                Side = side;
            }

            public override int CalculateCost()
            {
                return WarehouseOperations.Costs.LoadStore;
            }
        }

        /// <summary>
        /// Representation of a store container
        /// </summary>
        internal class StoreContainer : WarehouseOperation
        {
            public Aisle.Side Side { get; private set; }

            public StoreContainer( Aisle.Side side )
                : base( side )
            {
                Side = side;
            }

            public override int CalculateCost()
            {
                return WarehouseOperations.Costs.LoadStore;
            }
        }

        /// <summary>
        /// Representation of a pick operation
        /// </summary>
        internal class PickOrder : WarehouseOperation
        {
            public Order Order { get; private set; }
            public string ProductCode { get; private set; }
            public int Quantity { get; private set; }

            public PickOrder( Order order, string productCode, int quantity )
                : base( order.OrderCode, order.ProductCode, quantity )
            {
                this.Order = order;
                this.ProductCode = productCode;
                this.Quantity = quantity;
            }

            public override int CalculateCost()
            {
                return WarehouseOperations.Costs.PickOrder;
            }
        }
    }
}
