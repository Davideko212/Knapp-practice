﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using com.knapp.CodingContest.aisle;

namespace com.knapp.CodingContest.warehouse
{
    /// <summary>
    /// Class that represents the warehouse
    /// - contains all the data
    /// - provides all necessary functions
    /// - stores your moves to the result file
    /// </summary>
    public class Warehouse
    {
        /// <summary>
        /// Data coming from the data files (containers and products)
        /// </summary>
        private readonly InputData inputData;

        /// <summary>
        /// Internal representation of the moves
        /// </summary>
        public WarehouseOperations WarehouseOperations { get; private set; }

        /// <summary>
        /// Get the warehouse characteristics
        /// </summary>
        public WarehouseCharacteristics WarehouseCharacteristics { get; private set; }

        /// <summary>
        /// The aisles in the system
        /// </summary>
        public Aisle[] Aisles { get; private set; }

        /// <summary>
        /// The workstation of the system
        /// </summary>
        public WorkStation WorkStation { get; private set; }

        /// <summary>
        /// The shuttle of the installation
        /// </summary>
        public Shuttle Shuttle { get; private set; }

        /// <summary>
        /// create an instance of the warehouse
        /// </summary>
        /// <param name="inputData"></param>
        public Warehouse( InputData inputData )
        {
            this.inputData = inputData;
            this.WarehouseOperations = new WarehouseOperations( this );

            this.WarehouseCharacteristics = inputData.Characteristics;

            WorkStation = new WorkStation( this, WarehouseCharacteristics.WorkStationAisle );
            Shuttle = new Shuttle( this, new Position( WarehouseCharacteristics.WorkStationAisle , 0, Aisle.Side.None ) );

            Aisles = inputData.Aisles;
        }

        /// <summary>
        /// Get all containers that are in the warehouse
        /// (that is storage and workstation)
        /// </summary>
        /// <returns>the ContainerCollection containing all containers in the warehouse</returns>
        public ReadOnlyCollection<data.Container> GetAllContainers()
        {
            return inputData.GetContainers();
        }

        /// <summary>
        /// Get all orders that need to be picked
        /// Note: The orders must be picked in the sequence as they are in the list
        /// </summary>
        /// <returns>all orders</returns>
        public ReadOnlyCollection<data.Order> GetOrders()
        {
            return inputData.GetOrders();
        }

        /// <summary>
        /// calculate the cost for the given shuttle move
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public int CalculateMoveCost( Position from, Position to )
        {
            return WarehouseOperation.MoveShuttle.CalculateCost( from, to );
        }

        /// <summary>
        /// calculate the cost for the move from the current shuttle position to the given location
        /// </summary>
        /// <param name="to"></param>
        /// <returns></returns>
        public int CalculateMoveCost( Position to )
        {
            return CalculateMoveCost( Shuttle.CurrentPosition, to );
        }

        /// <summary>
        /// Get a specific lovation
        /// </summary>
        /// <param name="aisleNumber">number of the aisle</param>
        /// <param name="location">distance into the aisle</param>
        /// <param name="side">side of the aisle</param>
        /// <returns></returns>
        public Location GetLocation( int aisleNumber, int location, Aisle.Side side )
        {
            if ( aisleNumber >= 0 && aisleNumber < Aisles.Length )
            {
                return Aisles[ aisleNumber ].GetLocation( location, side );
            }

            throw new LocationNotFoundException("invalid aisle: " + aisleNumber );
        }

        /// <summary>
        /// Get the result (that is the list of all operations
        /// </summary>
        /// <returns>read-only list of all operations</returns>
        public ReadOnlyCollection<WarehouseOperation> GetResult()
        {
            return WarehouseOperations.GetOperations();
        }

        #region Statistics
        /// <summary>
        /// The current total cost of all executed operations
        /// </summary>
        public int CurrentOperationsCost => WarehouseOperations.CurrentOperationsCost;

        /// <summary>
        /// The current penalty for unfinished orders
        /// </summary>
        public int CurrentUnfinishedOrderCost => WarehouseOperations.CalculateUnfinishedOrderCost();

        /// <summary>
        /// The current penalty for not having cleaned up
        /// </summary>
        public int CurrentCleanUpCost => WarehouseOperations.CalculateCleanUpCost();

        /// <summary>
        /// The current over all total cost
        /// </summary>
        public int CurrentTotalCost => WarehouseOperations.CurrentTotalCost;
        #endregion
    }
}
