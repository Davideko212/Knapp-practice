﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.warehouse
{
    [Serializable]
    internal class UnexpectedOrderException : Exception
    {
        public UnexpectedOrderException( data.Order order, data.Order expectedOrder )
            :base( $"unexpected order {order}; expected {expectedOrder}"  )
        { /*** empy ***/ }

        public UnexpectedOrderException()
            : base()
        { /*** empy ***/ }

        public UnexpectedOrderException( string message ) : base( message )
        { /*** empy ***/ }

        public UnexpectedOrderException( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected UnexpectedOrderException( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}
