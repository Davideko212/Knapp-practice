﻿using System;
using System.Runtime.Serialization;

namespace com.knapp.CodingContest.warehouse
{
    [Serializable]
    internal class ProductMismatchExcpetion : Exception
    {
        public ProductMismatchExcpetion(string neededProductCode, string givenProductCode)
            : base($"Products do not match. Needed is '{neededProductCode}' but given was '{givenProductCode}'")
        { /*** empy ***/ }

        public ProductMismatchExcpetion( string message ) : base( message )
        { /*** empy ***/ }

        public ProductMismatchExcpetion( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected ProductMismatchExcpetion( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}