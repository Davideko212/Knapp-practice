﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.knapp.CodingContest.util;

namespace com.knapp.CodingContest.warehouse
{
    /// <summary>
    /// Settings for the warehouser
    /// </summary>
    public class WarehouseCharacteristics
    {
        /// <summary>
        /// Number of aisles in the installation
        /// </summary>
        public int NumberOfAisles { get; }

        /// <summary>
        /// number of locations per aisle
        /// </summary>
        public int NumberOfPositionsPerAisle { get; }

        /// <summary>
        /// depth of each location (number of containers that can be stored one after another)
        /// </summary>
        public int LocationDepth { get; }

        /// <summary>
        /// aisle of the workstation
        /// </summary>
        public int WorkStationAisle { get; }

        /// <summary>
        /// Ctor to create characteristics from property file
        /// </summary>
        /// <param name="properties"></param>
        public WarehouseCharacteristics( JavaPropertyFile properties )
        {
            NumberOfAisles = properties.GetInt( "numberOfAisles" );
            NumberOfPositionsPerAisle = properties.GetInt( "numberOfLocations" );
            LocationDepth = properties.GetInt( "locationDepth" );
            WorkStationAisle = properties.GetInt( "workStationAisle" );
        }
    }
}
