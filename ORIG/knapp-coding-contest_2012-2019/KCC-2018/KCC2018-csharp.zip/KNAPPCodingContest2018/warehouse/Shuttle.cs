﻿using System;
using com.knapp.CodingContest.aisle;
using com.knapp.CodingContest.data;
using com.knapp.CodingContest.util;

namespace com.knapp.CodingContest.warehouse
{
    public class Shuttle
    {
        /// <summary>
        /// The current location of this shuttle 
        /// </summary>
        public Position CurrentPosition { get; private set; }


        /// <summary>
        /// The currently loaded container, null if none is loaded
        /// </summary>
        public Container LoadedContainer { get; private set; } = null;


        /// <summary>
        /// Instance of the warehouse to store the movements
        /// </summary>
        private Warehouse warehouse;


        /// <summary>
        /// Create an instance of a shuttle
        /// </summary>
        /// <param name="warehouse">the surrounding warehouse</param>
        /// <param name="initialPosition">the location where the shuttle is initally</param>
        public Shuttle( Warehouse warehouse, Position initialPosition )
        {
            this.warehouse = warehouse;
            this.CurrentPosition = initialPosition;
        }

        /// <summary>
        /// Check if the shuttle is currently at a workstation
        /// </summary>
        /// <returns>true if the shuttle is at a workstation, false in any other case</returns>
        public bool IsAtWorkStation()
        {
            return CurrentPosition.DistanceIntoAisle < 0;
        }

        /// <summary>
        /// Get the location of the shuttle
        /// </summary>
        /// <param name="side">Which side of the shuttle to takte the location from</param>
        /// <returns>the location that is at the given side of the shuttle</returns>
        /// <exception cref="InvalidOperationException">When the shuttle is at a workstation</exception>
        public Location GetCurrentLocation( Aisle.Side side )
        {
            if( IsAtWorkStation() )
            {
                throw new InvalidOperationException("Shuttle at workstation, has no location");
            }

            return warehouse.Aisles[CurrentPosition.Aisle].GetLocation( CurrentPosition.DistanceIntoAisle, side );
        }

        /// <summary>
        /// Move the shuttle from the current location to the target location
        /// </summary>
        /// <param name="targetPosition">the location to move the shuttle to</param>
        /// <exception cref="ArgumentException">when targetPosition is null</exception>
        /// <exception cref="InvalidOperationException">when targetPosition is not a valid position</exception>
        public void MoveToPosition( Position targetPosition )
        {
            KContract.Assert( targetPosition != null, "location must not be null" );

            if( ! IsValidPosition( targetPosition ) )
            {
                throw new InvalidOperationException($"invalid position: {targetPosition}. Must be either WorksStation({warehouse.WorkStation}) or within extents of locations (>=0 - <{warehouse.WarehouseCharacteristics.NumberOfAisles}/ {warehouse.WarehouseCharacteristics.NumberOfPositionsPerAisle})");
            }

            if( IsAtWorkStation() )
            {
                warehouse.WorkStation.CurrentShuttle = null;
            }

            var oldPosition = CurrentPosition;
            CurrentPosition = new Position( targetPosition.Aisle, targetPosition.DistanceIntoAisle, Aisle.Side.None );

            if( IsAtWorkStation() )
            {
                warehouse.WorkStation.CurrentShuttle = this;
            }

            warehouse.WarehouseOperations.MoveShuttle( oldPosition, CurrentPosition );
        }

        /// <summary>
        /// Load the contaienr @ depth 0 from the given location
        /// </summary>
        /// <param name="location">the location from where to load a container</param>
        /// <param name="expectedContainer">the container that should be loaded</param>
        /// <exception cref="ArgumentException">when location is null</exception>
        /// <exception cref="ShuttleNotAtLocationException">when location is not the current location of the shuttle</exception>
        /// <exception cref="ShuttleLoadException">when the shuttle already has a container loaded</exception>
        public void LoadFromLocation( Location location, Container expectedContainer )
        {
            KContract.Assert( location != null, "Location must not be null" );

            if( LoadedContainer != null )
            {
                throw new ShuttleLoadException( "Shuttle already occupied" );
            }

            if( IsAtWorkStation() )
            {
                throw new ShuttleLoadException("Shuttle is at workstation, can not load from workstation.");
            }

            if ( ! IsSamePosition( CurrentPosition, location.Position ) )
            {
                throw new ShuttleNotAtLocationException( $"Shuttle not at psoition '{location.GetPositionString()}': " + ToString() );
            }

            if( ! location.IsReachable( expectedContainer ) )
            {
                throw new NoSuchContainerAtLocation($"Container {expectedContainer.ContainerCode} is not reachable on location {location}");
            }

            LoadedContainer = location.Pull();
            warehouse.WarehouseOperations.LoadContainer( location.Position.Side );
        }

        /// <summary>
        /// Store a container at the location at depth 0
        /// An existing container is pushed to depth 1
        /// </summary>
        /// <param name="location">the location to store the container in </param>
        /// <exception cref="ArgumentException">when location is null</exception>
        /// <exception cref="ShuttleNotAtLocationException">when the shuttle is not at the location</exception>
        /// <exception cref="ShuttleStoreException">when the shuttle has no container loaded</exception>
        public void StoreToLocation( Location location )
        {
            KContract.Assert( location != null, "Location must not be null" );

            if ( LoadedContainer == null )
            {
                throw new ShuttleStoreException( "Shuttle is empty." );
            }

            if( IsAtWorkStation() )
            {
                throw new InvalidOperationException("Cannot store to workstation");
            }

            if ( ! IsSamePosition( CurrentPosition, location.Position ) )
            {
                throw new ShuttleNotAtLocationException( $"Shuttle not at psoition '{location.GetPositionString()}': " + ToString() );
            }


            location.Push( LoadedContainer );
            LoadedContainer = null;

            warehouse.WarehouseOperations.StoreContainer( location.Position.Side );
        }

        /// <summary>
        /// Get human readable representation
        /// </summary>
        /// <returns>stringified instance</returns>
        public override string ToString()
        {
            return $"Shuttle [{LoadedContainer}] @ {GetPositionString()}";
        }

        /// <summary>
        /// Get the string representation of the current position
        /// </summary>
        /// <returns></returns>
        public string GetPositionString()
        {
            if ( IsAtWorkStation() )
            {
                return $"WORKSTATION @ A{CurrentPosition.Aisle,2}";
            }
            return CurrentPosition.GetPositionString();

        }

        /// <summary>
        /// Check if the position is valid
        /// </summary>
        /// <param name="position">the position to check</param>
        /// <returns>true if the position is valid, false in any other case</returns>
        private bool IsValidPosition( Position position)
        {
            if ( position.EqualsIgnoreSide( warehouse.WorkStation ) )
            {
                return true;
            }

            return ( ( ( position.Aisle >= 0 ) 
                    && ( position.Aisle < warehouse.WarehouseCharacteristics.NumberOfAisles ) ) ) //
                && ( ( ( position.DistanceIntoAisle >= 0 ) 
                    && ( position.DistanceIntoAisle < warehouse.WarehouseCharacteristics.NumberOfPositionsPerAisle ) ) );
        }

        /// <summary>
        /// Check if the positions are the same
        /// </summary>
        /// <param name="left">position to compare</param>
        /// <param name="right">position to compare</param>
        /// <returns>true if aisle and DistanceInto aisle are identical</returns>
        private bool IsSamePosition( Position left, Position right )
        {
            return left.Aisle == right.Aisle && left.DistanceIntoAisle == right.DistanceIntoAisle;
        }
    }
}
