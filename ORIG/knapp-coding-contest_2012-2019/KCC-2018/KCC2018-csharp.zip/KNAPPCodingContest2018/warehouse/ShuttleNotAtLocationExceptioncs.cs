﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.warehouse
{
    [Serializable]
    internal class ShuttleNotAtLocationException : Exception
    {
        public ShuttleNotAtLocationException()
            : base()
        { /*** empy ***/ }

        public ShuttleNotAtLocationException( string message ) : base( message )
        { /*** empy ***/ }

        public ShuttleNotAtLocationException( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected ShuttleNotAtLocationException( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}
