﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.CodingContest.warehouse
{
    [Serializable]
    internal class ShuttleStoreException : Exception
    {
        public ShuttleStoreException()
            : base()
        { /*** empy ***/ }

        public ShuttleStoreException( string message ) : base( message )
        { /*** empy ***/ }

        public ShuttleStoreException( string message, Exception innerException ) : base( message, innerException )
        { /*** empy ***/ }

        protected ShuttleStoreException( SerializationInfo info, StreamingContext context ) : base( info, context )
        { /*** empy ***/ }
    }
}
