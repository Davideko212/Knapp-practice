﻿using System;
using System.Linq;
using System.Collections.Generic;
using com.knapp.CodingContest.warehouse;
using com.knapp.CodingContest.util;
using com.knapp.CodingContest.data;

namespace com.knapp.KCC2018.solution
{
    public class Solution
    {

        /// <summary>
        /// 
        /// Your name
        /// Please set in constructor 
        /// </summary>
        public string ParticipantName { get; protected set; }

        /// <summary>
        /// 
        /// The Id of your institute - please refer to the handout
        /// Please set in constructor
        /// </summary>
        public Institutes Institute { get; protected set; }

        /// <summary>
        /// local reference to the global warehouse
        /// </summary>
        protected readonly Warehouse warehouse;

        /// <summary>
        /// Create the solution instance 
        /// 
        /// Do all your preparations here
        /// 
        /// </summary>
        public Solution( Warehouse warehouse )
        {
            KContract.Requires( warehouse != null, "input required but is null" );

            this.warehouse = warehouse;

            //YOUR CODE GOES HERE
            ParticipantName = 
            Institute = Institutes.
        }

        public virtual void RunWarehouseOperations()
        {

            //YOUR CODE GOES HERE
        }
    }
}
