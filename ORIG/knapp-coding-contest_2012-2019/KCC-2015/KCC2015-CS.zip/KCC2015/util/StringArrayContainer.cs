﻿using System.Diagnostics.Contracts;
using System.Text;


namespace com.knapp.KCC.util
{
    /// <summary>
    /// Helper class to store string array in an instance
    /// </summary>
    public class StringArrayContainer
    {

        /// <summary>
        /// Returns the stored array
        /// </summary>
        public string[ ] Strings { get; private set; }

        /// <summary>
        /// Get the string at the given array index (0-based)
        /// </summary>
        /// <param name="index">index from which to get the single string</param>
        /// <returns>string</returns>
        public string this[int index]
        {
            get
            {
#if __SG_CONTRACTS
                Contract.Requires( index >=0, "index must be >=0");
                Contract.Requires( index < Strings.Length, "index must be less than the number of strings held" );
#endif
                return Strings[ index ];
            }
        }

        public int Count {  
            get
            {
                return Strings.Length;
            }
          }

        /// <summary>
        /// Create an instance and store the given string array
        /// </summary>
        /// <param name="data">the string array to store</param>
        public StringArrayContainer( string[ ] data )
        {
#if __SG_CONTRACTS
            Contract.Requires( data != null, "data is mandatory but is null" );
#endif
            this.Strings = data;
        }

        /// <summary>
        /// Get a string representation of the contained strings
        /// </summary>
        /// <returns>stringified content</returns>
        public override string ToString( )
        {
            StringBuilder sb = new StringBuilder( );

            sb.Append( "[" );
            foreach( string s in Strings )
            {
                if (sb.Length > 1 )
                {
                    sb.Append( "," );
                }
                sb.Append( "'" ).Append( s ).Append( "'" );
            }
            sb.Append( "]" );

            return sb.ToString( );
        }
    }
}