﻿using com.knapp.KCC2015.data;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015
{
    public class Output
    {
        private readonly string filename;

        public Output( string filename )
        {
            Contract.Requires( !string.IsNullOrWhiteSpace( filename ), "filename is mandatory but is null or whitespace" );

            this.filename = Path.Combine( Settings.OutputPath, filename );
        }

        /// <summary>
        /// write locationCode/ productCode - tuple into csv
        /// 
        /// WARNING: The output format must nor be changed, otherwise the result can and will not be ranked
        /// 
        /// </summary>
        /// <param name="zoneCollection"></param>
        public void Write( ZoneCollection zoneCollection )
        {
#if __SG_CONTRACTS
            Contract.Requires( zoneCollection != null, "zoneCollection mandatory but is null" );
#endif
            Cleanup( );

            int recordCount = 0;
            using ( StreamWriter writer = new StreamWriter( filename, false ) )
            {
                foreach ( Zone zone in zoneCollection.GetZones( ) )
                {
                    foreach ( Shelf shelf in zone.GetShelves( ) )
                    {
                        foreach ( Location location in shelf.GetLocations( ) )
                        {
                            if ( location.IsProductAssigned( ) )
                            {
                                writer.WriteLine( "{0};{1};", location.Code, location.GetAssignedProduct().Code );

                                writer.Flush( );
                                ++recordCount;
                            }
                        }
                    }
                    writer.WriteLine( );
                    writer.Flush( );
                }
            }

            System.Console.Out.WriteLine( "+++ Wrote {0} records to output file '{1}'"
                                        , recordCount
                                        , filename
                                        );
        }

        private void Cleanup()
        {
            if ( File.Exists( filename ) )
            {
                File.Delete( filename );
            }
        }
    }
}
