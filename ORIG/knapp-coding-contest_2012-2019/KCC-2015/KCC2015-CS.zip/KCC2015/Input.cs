﻿using com.knapp.KCC.util;
using com.knapp.KCC2015.data;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015
{
    /// <summary>
    /// Container class for all input into the solution
    /// </summary>
    public class Input
    {
        /// <summary>
        /// Container for all zones in the warehouse
        /// (and contained therein all shelves and locations)
        /// </summary>
        public ZoneCollection ZoneCollection { get; private set; }

        /// <summary>
        /// Container for all products that have to be slotted (assigned to locations)
        /// </summary>
        public ProductCollection ProductCollection { get; private set; }


        /// <summary>
        /// Container for all pickorders that will be picked out of the warehouse
        /// U do not need to implement picking, this will be done by KNAPP during
        /// evaluation
        /// </summary>
        public PickOrderCollection PickOrderCollection { get; private set; }

        /// <summary>
        /// Create from outside only via CreateFromCsv
        /// </summary>
        private Input( )
        { }

        /// <summary>
        /// Load all input data from the csv files and crete instance (and composite instances)
        /// </summary>
        /// <returns>a newly created ínstance of the inout</returns>
        public static Input CreateFromCsv()
        {
            Input input = new Input();

            string zoneFile = System.IO.Path.Combine( Settings.DataPath, @"zones.csv" );
            input.ZoneCollection = ZoneCollection.CreateFromCsv( zoneFile );

            LoadLocations( input, System.IO.Path.Combine( Settings.DataPath, @"locations.csv" ) );


            input.ProductCollection = ProductCollection.CreateFromCsv( System.IO.Path.Combine( Settings.DataPath, @"products.csv" ) );

            input.PickOrderCollection = PickOrderCollection.CreateFromCsv( System.IO.Path.Combine( Settings.DataPath, @"pickorders.csv" ) );

            input.ZoneCollection.Dump( System.Console.Out );

            return input;
        }

        //Load locations file
        private static void LoadLocations( Input input, string fullFilename )
        {
#if __SG_CONTRACTS
            Contract.Requires( input != null );
            Contract.Requires( ! string.IsNullOrWhiteSpace( fullFilename ) );
#endif
            int recordCount = 0;
            foreach ( StringArrayContainer sac in CsvReader.ReadCsvFile<StringArrayContainer>( fullFilename ) )
            {
                Zone zone = input.ZoneCollection.GetZoneByName( sac[ 0 ] );

                if ( zone != null )
                {
                    Shelf shelf = null;

                    if ( zone.HasShelf( sac[ 1 ] ) )
                    {
                        shelf = zone.GetShelf( sac[ 1 ] );
                    }
                    else
                    {
                        shelf = zone.CreateShelf( sac[ 1 ] );
                    }

                    shelf.CreateLocation( sac[ 2 ] );
                    ++recordCount;

                }
                else
                {
                    System.Console.Error.WriteLine( "!!! KNAPP ERROR: Zone '{0}' not found while loading locations.", sac[ 0 ] );
                    Environment.Exit( -2 );
                }
            }

            System.Console.Out.WriteLine( "+++ Loaded {0} locations", recordCount );
        }
    }
}
