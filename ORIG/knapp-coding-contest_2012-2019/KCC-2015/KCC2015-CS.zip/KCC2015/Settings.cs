﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015
{
    public class Settings
    {
        public static string DataPath { get; private set; }
        public static string OutputPath { get; private set; }


        static Settings( )
        {
            DataPath = @"input";
            OutputPath = @"";
        }
    }
}
