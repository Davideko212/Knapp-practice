﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// A product that is handled in a warehouse
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Unique code of this product
        /// </summary>
        public string Code { get; private set; }

        /// <summary>
        /// Does this product require cool storage
        /// </summary>
        public bool Cool { get; private set; }

        /// <summary>
        /// Does this product require frozen storage
        /// </summary>
        public bool Frozen { get; private set; }

        /// <summary>
        /// Is this product valuable and therefore needs secure storage
        /// </summary>
        public bool Valuable { get; private set; }

        /// <summary>
        /// Get stringified representation of this instance
        /// </summary>
        /// <returns>strign with infos for this instance</returns>
        public override string ToString( )
        {
            return string.Format("{0}: {1:6}/{2:6}/{3:6}"
                                , Code
                                , Cool
                                , Frozen
                                , Valuable
                                );
        }

        /// <summary>
        /// Create a product from the given data
        /// </summary>
        /// <param name="dataAsArray"></param>
        public Product( string[] dataAsArray )
        {
#if __SG_CONTRACTS
            Contract.Requires( dataAsArray != null, "dataAsArray mandatory but is null" );
            Contract.Requires( dataAsArray.Length == 4, "dataAsArray must contain 4 elements"  );
#endif
            Code = dataAsArray[ 0 ].Trim( );

            Cool = bool.Parse( dataAsArray[ 1 ] );
            Frozen = bool.Parse( dataAsArray[ 2 ] );
            Valuable  = bool.Parse( dataAsArray[ 3 ] );

            Validate( );
        }

        /// <summary>
        /// quick validation of the product data 
        /// </summary>
        private void Validate()
        {
#if __SG_CONTRACTS
            Contract.Assert( !string.IsNullOrWhiteSpace( Code ), "Code must be given but is null or whitespace" );
#endif
        }
    }
}
