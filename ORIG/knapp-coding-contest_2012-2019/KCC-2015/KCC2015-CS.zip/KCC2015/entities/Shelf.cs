﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// A shelf that holds a number of locations
    /// </summary>
    public class Shelf
    {
        private readonly Dictionary<string, Location> locations = new Dictionary<string, Location>( );

        /// <summary>
        /// Get the unique code for this shelf
        /// </summary>
        public string Code { get; private set; }

        /// <summary>
        /// Create shelf and set the given code
        /// </summary>
        /// <param name="code">the code to set</param>
        public Shelf( string code )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( code ), "code is mandatory but is null or whitespace" );
#endif

            this.Code = code;
        }


        /// <summary>
        /// Get the next free location in this shelf
        /// </summary>
        /// <returns>the next free location in this shelf; null if none could be found</returns>
        public Location GetNextFreeLocation( )
        {
            foreach( Location location in locations.Values )
            {
                if ( ! location.IsProductAssigned() )
                {
                    return location;
                }
            }

            return null;
        }

        /// <summary>
        /// Get an enumerator for all locations of this shelf
        /// </summary>
        /// <returns>enumerator for all locations of this shelf</returns>
        public IEnumerable<Location> GetLocations( )
        {
            foreach ( Location location in locations.Values )
            {
                yield return location;
            }
        }


        /// <summary>
        /// Create a location with the given code inside this shelf
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public Location CreateLocation( string code )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( code ), "code mandatory but is null or whitespace" );              
#endif
            if ( !locations.ContainsKey( code ) )
            {
                Location location = new Location( code );
                
                locations.Add( code, location );
                
                return location;
            }

            return locations[ code ];
        }
    }
}
