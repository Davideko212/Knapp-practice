﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// A PickOrder (Kommissionierauftrag) which should be packed in the warehouse
    /// with the current assignment of products
    /// </summary>
    public class PickOrder
    {

        /// <summary>
        /// Get the unique Id for this order
        /// </summary>
        public string OrderId { get; private set; }

        private readonly List<PickOrderLine> orderLines = new List<PickOrderLine>( );


        /// <summary>
        /// Create a PickOrder instance with the given id
        /// </summary>
        /// <param name="orderId">OrderId to use</param>
        public PickOrder( string orderId )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( orderId ), "orderId mandatory but is null" );
#endif

            OrderId = orderId;
        }

        /// <summary>
        /// Get iterator for the PickOrderLines in this order
        /// </summary>
        /// <returns>iterator for the pickorderlines</returns>
        public IReadOnlyCollection<PickOrderLine> GetPickOrderLines( )
        {
            return orderLines.AsReadOnly( );
        }

        /// <summary>
        /// Add a product to this order
        /// Creates a new pickorderline for this product
        /// </summary>
        /// <param name="productCode"></param>
        public void Add( string productCode )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( productCode ), "productCode mandatory but is null or whitespace" );
#endif
            orderLines.Add( new PickOrderLine( productCode ) );
        }
    }
}
