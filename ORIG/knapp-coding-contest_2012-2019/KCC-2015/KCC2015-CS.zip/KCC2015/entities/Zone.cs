﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// A specific zone within a warehouse that provides specific storage conditions
    /// </summary>
    public class Zone
    {
        private readonly Dictionary<string, Shelf> shelves = new Dictionary<string, Shelf>( );

        /// <summary>
        /// Uniqhe name of the zone
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Does this zone provide cool storage?
        /// </summary>
        public bool Cool { get; private set; }

        /// <summary>
        /// Does this zone provide frozen storage
        /// </summary>
        public bool Frozen { get; private set; }

        /// <summary>
        /// Does this zone provide secure storage for valuable items
        /// </summary>
        public bool Valuable { get; private set; }

        /// <summary>
        /// The cost for retrieving a product from a location of a shelf
        /// </summary>
        public int CostPerLocation { get; private set; }

        /// <summary>
        /// The cost for using a shelf to pack an order (once per order)
        /// </summary>
        public int CostPerShelfVisit { get; private set; }

        /// <summary>
        /// Gets the next free location in this zone.
        /// --> Hint: This is a straight forward implementation and may not yield the best result!!
        /// </summary>
        /// <returns>the next free location in this zone (not optimal!!); null if none is free</returns>
        public Location GetNextFreeLocation( )
        {

            foreach ( Shelf shelf in shelves.Values )
            {
                Location freeLocation = shelf.GetNextFreeLocation( );

                if ( freeLocation != null )
                {
                    return freeLocation;
                }
            }

            return null;
        }

        /// <summary>
        /// Get an enumerator for all shelves in this zone
        /// </summary>
        /// <returns>enumerator for shelves</returns>
        public IEnumerable<Shelf> GetShelves( )
        {
            foreach ( Shelf shelf in shelves.Values )
            {
                yield return shelf;
            }
        }

        
        /// <summary>
        /// Construct the zone from the given data
        /// </summary>
        /// <param name="dataAsArray">data to construct this instance from</param>
        public Zone( string[] dataAsArray )
        {
#if __SG_CONTRACTS
            Contract.Requires( dataAsArray != null, "dataAsArray mandatory but is null" );
            Contract.Requires( dataAsArray.Length == 6, "zone record must have 6 fields" );
#endif
            Name = dataAsArray[ 0 ].Trim( );

            Cool = bool.Parse( dataAsArray[ 1 ] );

            Frozen = bool.Parse( dataAsArray[ 2 ] );

            Valuable = bool.Parse( dataAsArray[ 3 ] );

            CostPerLocation = int.Parse( dataAsArray[ 4 ] );

            CostPerShelfVisit = int.Parse( dataAsArray[ 5 ] );

            Validate( );
        }

        /// <summary>
        /// simple validation for data in ctor
        /// </summary>
        private void Validate()
        {
#if __SG_CONTRACTS
            Contract.Assert( !string.IsNullOrWhiteSpace( Name ), "Name must be set but is not" );
            Contract.Assert( CostPerLocation > 0, "CostPerLocation must be >0" );
            Contract.Assert( CostPerShelfVisit > 0, "CostPerShelfVisit must be >0" );
            Contract.Assert( !Cool || !Frozen , "Cool and Frozen are mutually exclusive" );
#endif
        }
        
        /// <summary>
        /// get stringified representation for this zone
        /// </summary>
        /// <returns>stringified representation of this object</returns>
        override public string ToString()
        {
            return string.Format("{0}: Cool: {1}; Frozen: {2}; Valuable: {3}; CostPerLocation: {4}; CostPerShelfVisit {5}- {6} shelves"
                                    , Name
                                    , Cool
                                    , Frozen
                                    , Valuable
                                    , CostPerLocation
                                    , CostPerShelfVisit
                                    , shelves.Count
                                    );
        }

        /// <summary>
        /// Create the shelf with the given Code
        /// used for creating from csv
        /// </summary>
        /// <param name="code">Code to use for new shelf</param>
        /// <returns>an instance of the new shelf</returns>
        public Shelf CreateShelf( string code )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( code ), "code mandatory but is null or whitespace" );
            Contract.Assert( ! HasShelf( code ), "Shelf must not exist but does: " + code  );
#endif
            Shelf shelf = new Shelf( code );

            shelves.Add( code, shelf );

            return shelf;
        }

        /// <summary>
        /// Get the shelf for the given code
        /// </summary>
        /// <param name="code">code of the shelf to get</param>
        /// <returns>the shelf for the given code if found; null otherwise</returns>
        public Shelf GetShelf( string code  )
        {
            if ( HasShelf( code ) )
            {
                return shelves[ code ];
            }

            return null;
        }

        /// <summary>
        /// Is there a shelf with the given code?
        /// </summary>
        /// <param name="code">code for the shelf to check</param>
        /// <returns>true if a shelf for the given code was found; false otherwise</returns>
        public bool HasShelf( string code )
        {
            return shelves.ContainsKey( code );
        }
    }
}
