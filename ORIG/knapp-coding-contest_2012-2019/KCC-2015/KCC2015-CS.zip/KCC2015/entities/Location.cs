﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// represents a location within a shelf that can hold one single product
    /// </summary>
    public class Location
    {
        /// <summary>
        /// Get the unique code of the location
        /// </summary>
        public string Code { get; private set; }


        private Product assignedProduct = null;

        /// <summary>
        /// Construct a location an set it'sunique code
        /// </summary>
        /// <param name="code"></param>
        public Location( string code )
        {
            this.Code = code;
        }

        /// <summary>
        /// Assign a new product to this location.
        /// if a product was previously assigned, it is returned
        /// </summary>
        /// <param name="product">the product to assign to this locatoin</param>
        /// <returns>Product - a previously assigned product or null if none was assgigned</returns>
        public Product Assign( Product product )
        {
#if __SG_CONTRACTS
            Contract.Requires( product != null, "product is mandatory but is null");
#endif

            Product priorProduct = assignedProduct;

            assignedProduct = product;

            return priorProduct;
        }

        /// <summary>
        /// Queries wether a product is currently assigned to this location
        /// </summary>
        /// <returns>true -a product is assigned; false otherwise</returns>
        public bool IsProductAssigned()
        {
            return null != assignedProduct;
        }

        /// <summary>
        /// Return the currently assigned product
        /// </summary>
        /// <returns>currently assigned product or null of none is assigned</returns>
        public Product GetAssignedProduct()
        {
            return assignedProduct;
        }

        /// <summary>
        /// Unassign a location
        /// </summary>
        /// <returns>the previously assigned product or nullif none was assigned</returns>
        public Product ClearAssignedProduct()
        {
            Product priorProduct = assignedProduct;

            assignedProduct = null;

            return priorProduct;
        }

        /// <summary>
        /// Get a stringified representation of the object
        /// </summary>
        /// <returns></returns>
        public override string ToString( )
        {
            if ( IsProductAssigned( ) )
            {
                return string.Format( "[{0}] holds {1}"
                                        , Code
                                        , assignedProduct.Code
                                        );
            }
            else
            {
                return string.Format( "[{0}] is unassigned"
                                        , Code
                                        );
            }
        }
    }
}
