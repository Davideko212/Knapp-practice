﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.entities
{
    /// <summary>
    /// Represents a product that must be packedfor a PickOrder
    /// </summary>
    public class PickOrderLine
    {
        /// <summary>
        /// The code of the product to pack
        /// </summary>
        public string ProductCode { get; private set; }


        /// <summary>
        /// Create a PickorderLine for the given product
        /// </summary>
        /// <param name="productCode"></param>
        public PickOrderLine( string productCode )
        {
#if __SG_CONTRACTS
            Contract.Requires( ! string.IsNullOrWhiteSpace( productCode ), "productCode mandatory but is null");
#endif

            ProductCode = productCode;
        }
    }
}
