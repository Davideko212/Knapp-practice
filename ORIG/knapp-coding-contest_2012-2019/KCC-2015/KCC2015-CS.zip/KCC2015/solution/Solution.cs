﻿using com.knapp.KCC2015.data;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace com.knapp.KCC2015.solution
{
    public class Solution
    {
        /// <summary>
        /// Create the solution instance 
        /// Default ctor is mandatory! (Unless of course u change the calling code as well ;-)
        /// </summary>
        public Solution()
        { }

        /// <summary>
        /// Assign all products from input.ProductCollection to locations in input.ZoneCollection 
        /// so that the pickorders from input.PickOrderCollection can be processed as efficient as
        /// possible
        /// </summary>
        /// <param name="input">instance holding all input data</param>
        public void AssignProducts( Input input )
        {
            //TODO: Hier die eigene Lösung implementieren
            //TODO: Alle Produkte in input.ProductCollection müssen einer passenden Location 
            //TODO:  in input.ZoneCollection zugeordnet sein.
            //TODO: Die Aufträge in input.PickOrderCollection müssen danach so billig wie 
            //TODO:  möglich abgearbeitet werden können
            //TODO: Nicht vergessen: cc150306.properties ändern!         

            //TODO: Die Lösung wird aus input.ZoneCollection gelesen. Die Produkte müssen also dort zugeordnet sein
        }
    }
}
