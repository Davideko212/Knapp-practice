﻿using com.knapp.KCC.util;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.data
{
    public class PickOrderCollection
    {
        private readonly Dictionary<string, PickOrder> orders = new Dictionary<string, PickOrder>( );

        /// <summary>
        /// PickOrderCollection can only be created via CreatFromCsv
        /// </summary>
        private PickOrderCollection( )
        { }


        /// <summary>
        /// Get an enumerator for all PickOrders
        /// </summary>
        /// <returns>the enumerator for all PickOrder</returns>
        public IEnumerable<PickOrder> GetPickOrders()
        {
            foreach( PickOrder pickOrder in orders.Values )
            {
                yield return pickOrder;
            }
        }

        /// <summary>
        /// Get the total number of PickOrders in this collection
        /// </summary>
        public int Count
        {
            get
            {
                return orders.Count;
            }
        }
        
        /// <summary>
        /// load the PickOrders from the csv and create the objects
        /// </summary>
        /// <param name="fullFilename">full path of the csv</param>
        /// <returns>new PickOrderCollection with all PickOrder and their PickOrderLines from the csv</returns>
        public static PickOrderCollection CreateFromCsv( string fullFilename )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "filename mandatory but is null" );
#endif

            PickOrderCollection orderCollection = new PickOrderCollection( );

            int lineCount = 0;
            foreach ( StringArrayContainer sac in CsvReader.ReadCsvFile<StringArrayContainer>( fullFilename ) )
            {
                if ( sac.Count == 2 )
                {
                    PickOrder order;

                    if ( orderCollection.orders.ContainsKey( sac[ 0 ] ) )
                    {
                        order = orderCollection.orders[ sac[ 0 ] ];
                    }
                    else
                    {
                        order = new PickOrder( sac[ 0 ] );
                        orderCollection.orders.Add( order.OrderId, order );
                    }

                    order.Add( sac[ 1 ] );
                    ++lineCount;
                }
                else
                {
                    throw new ArgumentOutOfRangeException( "orderline must have two fields but has: " + sac.Count );
                }
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} orders with {1} lines"
                                            , orderCollection.Count
                                            , lineCount
                                            );

            return orderCollection;
        }
    }
}
