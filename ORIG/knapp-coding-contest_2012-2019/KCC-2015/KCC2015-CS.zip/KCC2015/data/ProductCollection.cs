﻿using com.knapp.KCC.util;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015.data
{
    public class ProductCollection
    {
        private readonly Dictionary<string, Product> products = new Dictionary<string, Product>( );

        /// <summary>
        /// A product collection can only be created using CreateFromCsv
        /// </summary>
        private ProductCollection()
        { }

        /// <summary>
        /// Get the total number of products currently in this collection
        /// </summary>
        public int Count
        {
            get
            {
                return products.Count;
            }
        }

        /// <summary>
        /// Get the product with the given code
        /// </summary>
        /// <param name="productCode">code of the product to return</param>
        /// <returns>product with the given code if it was found in the collection; null otherwise</returns>
        public Product GetProduct( string productCode )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( productCode ), "productCode mandatory but is null or whitespace" );
#endif

            if ( products.ContainsKey( productCode ) )
            {
                return products[ productCode ];
            }

            return null;
        }

        /// <summary>
        /// Get an enumerator for all products in the collection
        /// </summary>
        /// <returns>an enumerator for all products</returns>
        public IEnumerable<Product> GetProducts()
        {
            foreach( Product product in products.Values )
            {
                yield return product;
            }
        }

        /// <summary>
        /// Create a ProductColleciton and load products from given csv
        /// </summary>
        /// <param name="fullFilename"></param>
        /// <returns>newly created instance</returns>
        public static ProductCollection CreateFromCsv( string fullFilename )
        {
#if __SG_CONTRACTS
            Contract.Requires( ! string.IsNullOrWhiteSpace( fullFilename  ), "fullFilename mandatory but is null or whitespace");
#endif

            ProductCollection productCollection = new ProductCollection( );

            foreach ( Product product in CsvReader.ReadCsvFile<Product>( fullFilename ) )
            {
                productCollection.Add( product );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} products", productCollection.Count );

            return productCollection;
        }

        /// <summary>
        /// Add a product to the collection
        /// </summary>
        /// <param name="product">the product to add</param>
        private void Add( Product product )
        {
#if __SG_CONTRACTS
            Contract.Requires( product != null, "product mandatory but is null");
#endif

            products.Add( product.Code, product );
        }
    }
}
