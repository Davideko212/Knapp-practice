﻿using com.knapp.KCC.util;
using com.knapp.KCC2015.entities;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;

namespace com.knapp.KCC2015.data
{
    /// <summary>
    /// Holds a colleciotion of all zones in the warehouse
    /// </summary>
    public class ZoneCollection
    {
        private readonly Dictionary<string, Zone> zones = new Dictionary<string, Zone>( );

        //Create from outside via call to CreateFromCsv
        private ZoneCollection( )
        { }

        /// <summary>
        /// Get the number of zones in this collection (warehouse)
        /// </summary>
        public int Count
        {
            get
            {
                return zones.Count;
            }
        }

        /// <summary>
        /// Get a zone by it's name
        /// </summary>
        /// <param name="name">name of the zone to return</param>
        /// <returns>the zone with the geiven name; null if it was not found</returns>
        public Zone GetZoneByName( string name )
        {
            if ( zones.ContainsKey( name ) )
            {
                return zones[ name ];
            }

            return null;
        }

        /// <summary>
        /// An enumerator for all zones so you can 
        /// foreach( Zone zone in zoneCollection.GetZones() )
        /// {...}
        /// </summary>
        /// <returns>an enumerator for all zones</returns>
        public IEnumerable<Zone> GetZones( )
        {
            foreach( Zone zone in zones.Values )
            {
                yield return zone;
            }
        }


        /// <summary>
        /// Write the currently loaded zones on the specified stream
        /// </summary>
        /// <param name="stream"></param>
        public void Dump( TextWriter stream )
        {
#if __SG_CONTRACTS
            Contract.Requires( stream != null, "stream mandatory but is null" );
#endif

            stream.WriteLine( "+++ {0} Zones defined in warehouse:", zones.Count );

            foreach( Zone zone in zones.Values )
            {
                stream.WriteLine( "   {0}", zone.ToString() );
            }

            stream.WriteLine("------------------------------------------------------------------------" );
        }


        /// <summary>
        /// Load the zones from the specified file
        /// Format of csv:
        /// zone_name: string,  cool: bool, frozen: bool, vault: bool, locationCost: int
        /// </summary>
        /// <param name="filename">csv file from which to load the zones</param>
        public static ZoneCollection CreateFromCsv( string fullFilename )
        {
#if __SG_CONTRACTS
            Contract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "filename mandatory but is null" );
#endif


            ZoneCollection zoneCollection = new ZoneCollection( );

            foreach ( Zone zone in CsvReader.ReadCsvFile<Zone>( fullFilename ) )
            {
                zoneCollection.Add( zone );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} zones", zoneCollection.Count );

            return zoneCollection;
        }


        /// <summary>
        /// Add a zone to the collection
        /// </summary>
        /// <param name="zone">the zone to add</param>
        private void Add( Zone zone )
        {
#if __SG_CONTRACTS
            Contract.Requires( zone != null, "zone mandatory but is null" );
#endif

            zones.Add( zone.Name, zone );
        }
    }
}
