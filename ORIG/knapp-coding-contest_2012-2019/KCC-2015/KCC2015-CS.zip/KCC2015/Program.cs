﻿using com.knapp.KCC2015.data;
using com.knapp.KCC2015.entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2015
{
    class Program
    {
        static void Main( string[ ] args )
        {
            Input input = null;
            try
            {
                input = Input.CreateFromCsv( );

                System.Console.Out.WriteLine( "### Your output starts here" );
            }
            catch( Exception e )
            {
                ShowException( e, "Exception in startup/ wrap-up code" );
                Environment.Exit( -1 );
            }

            try
            {
                solution.Solution solution = new solution.Solution( );
                solution.AssignProducts( input );

                System.Console.Out.WriteLine( "### Your output stops here" );
            }
            catch( Exception e )
            {
                ShowException( e, "Exception in application code" );
                Environment.Exit( -2 );
            }

            try
            {
                Output output = new Output( "assignments.csv" );
                output.Write( input.ZoneCollection );
            }
            catch( Exception e )
            {
                ShowException( e, "Exception in startup/ wrap-up code" );
                Environment.Exit( -3 );
            }

            System.Console.Out.WriteLine( "Press <enter>" );
            System.Console.In.ReadLine( );
        }

        private static void ShowException( Exception e, string codeSegment )
        {
#if __SG_CONTRACTS
            Contract.Requires( e != null, "e is mandatory but is null" );
            Contract.Requires( ! string.IsNullOrWhiteSpace(codeSegment), "codeSegment is mandatory but is null or whitespace" );
#endif
            System.Console.Error.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
            System.Console.Error.WriteLine(  codeSegment );
            System.Console.Error.WriteLine( "[{0}]: {1}", e.GetType().Name, e.ToString() );
            
            if ( e.Data != null && e.Data.Count > 0 )
            {
                System.Console.Error.WriteLine( "Data in exception:" );
                foreach( KeyValuePair<string, string> elem in e.Data )
                {
                    System.Console.Error.WriteLine( "[{0}] : '{1}'", elem.Key, elem.Value );
                }
            }
            System.Console.Error.WriteLine( "------------------------------------------------" );

            System.Console.Error.WriteLine( e.StackTrace );

            System.Console.Error.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );

            System.Console.Out.WriteLine( "Press <enter>" );
            System.Console.In.ReadLine( );
        }
    }
}
