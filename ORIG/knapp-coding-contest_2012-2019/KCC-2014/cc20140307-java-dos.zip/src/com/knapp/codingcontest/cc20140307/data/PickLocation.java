/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307.data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PickLocation extends Location {
  private final String productCode;
  private final long expiryDate;
  private final int stockQuantity;

  // ----------------------------------------------------------------------------

  public PickLocation(final String locationCode, final int x, final int y, //
      final String productCode, final Date expiryDate, final int stockQuantity) {
    super(locationCode, x, y);
    this.productCode = productCode;
    this.expiryDate = expiryDate.getTime();
    this.stockQuantity = stockQuantity;
  }

  // ----------------------------------------------------------------------------

  public String getProductCode() {
    return productCode;
  }

  public Date getExpiryDate() {
    return new Date(expiryDate);
  }

  public int getStockQuantity() {
    return stockQuantity;
  }

  // ----------------------------------------------------------------------------

  @Override
  public String toString() {
    return "PickLocation[" + getCode() + ":" + getX() + "/" + getY() + ":[" + productCode + "#" + stockQuantity + "{"
        + formatDate(getExpiryDate()) + "}]]";
  }

  // ----------------------------------------------------------------------------

  private static DateFormat DATE_FORMAT_EXPIRY_DATE = new SimpleDateFormat("yyyy-MM-dd");

  private String formatDate(final Date date) {
    synchronized (PickLocation.DATE_FORMAT_EXPIRY_DATE) {
      return PickLocation.DATE_FORMAT_EXPIRY_DATE.format(date);
    }
  }
}
