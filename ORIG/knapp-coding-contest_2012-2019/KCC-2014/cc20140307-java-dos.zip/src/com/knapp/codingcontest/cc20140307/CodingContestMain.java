/* -*- java -*- ************************************************************************** *
 *
 *                     Copyright (C) KNAPP AG
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.knapp.codingcontest.cc20140307.data.PickOrderCollection;
import com.knapp.codingcontest.cc20140307.orderplanning.OrderPlanning;

public class CodingContestMain {
  // ----------------------------------------------------------------------------

  public static void main(final String... args) throws Exception {
    System.out.println("KNAPP Coding Contest 2014: STARTING...");

    final Properties properties = new Properties();
    properties.load(new FileInputStream("cc20140307.properties"));
    final String basedir = System.getProperty("basedir", properties.getProperty("basedir", "."));
    final String dataPath = basedir + File.separator + "data";
    final String resultPath = basedir;

    System.out.println("... LOADING DATA ...");
    final InputData inputData = CodingContestMain.createInputData(dataPath);

    System.out.println("... CREATE PICK-ORDERS ...");
    final OrderPlanning orderPlanning = new OrderPlanning(inputData);
    final PickOrderCollection pickOrders = orderPlanning.createPickOrders();

    System.out.println("... WRITING OUTPUT/RESULT ...");
    final OutputData outputData = new OutputData(resultPath);
    outputData.writeOutput(pickOrders);

    System.out.println("KNAPP Coding Contest 2014: FINISHED");
  }

  // ----------------------------------------------------------------------------

  private static InputData createInputData(final String dataPath) throws IOException {
    final InputData inputData = new InputData(dataPath);
    inputData.readData();
    return inputData;
  }

  // ----------------------------------------------------------------------------
}
