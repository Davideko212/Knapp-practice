/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import com.knapp.codingcontest.cc20140307.data.PickLine;
import com.knapp.codingcontest.cc20140307.data.PickOrder;
import com.knapp.codingcontest.cc20140307.data.PickOrderCollection;

public class OutputData {
  private final String resultPath;

  // ----------------------------------------------------------------------------

  public OutputData(final String resultPath) {
    this.resultPath = resultPath;
  }

  // ----------------------------------------------------------------------------

  public void writeOutput(final PickOrderCollection pickOrders) throws IOException {
    final Writer fw = new FileWriter(fullFileName("pick-orders.csv"));
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(fw);
      // order-id;put-loc;(pick-loc;quantity;)+
      for (final PickOrder pickOrder : pickOrders.getPickOrders()) {
        writer.append(pickOrder.getId()).append(";");
        writer.append(pickOrder.getPutLocationCode()).append(";");
        for (final PickLine pickLine : pickOrder.getPickLines()) {
          writer.append(pickLine.getPickLocationCode()).append(";");
          writer.append(Integer.toString(pickLine.getPickedQuantity())).append(";");
        }
        writer.newLine();
      }
    } finally {
      close(writer);
      close(fw);
    }
  }

  // ----------------------------------------------------------------------------

  private File fullFileName(final String fileName) {
    final String fullFileName = resultPath + File.separator + fileName;
    return new File(fullFileName);
  }

  private void close(final Closeable closeable) {
    if (closeable != null) {
      try {
        closeable.close();
      } catch (final IOException exception) {
        exception.printStackTrace(System.err);
      }
    }
  }

  // ----------------------------------------------------------------------------
}
