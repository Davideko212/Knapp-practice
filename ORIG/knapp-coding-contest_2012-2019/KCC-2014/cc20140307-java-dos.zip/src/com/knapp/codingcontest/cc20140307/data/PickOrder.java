/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PickOrder {
  private final String id;
  private final List<PickLine> pickLines = new ArrayList<PickLine>();
  private String putLocationCode;

  // ----------------------------------------------------------------------------

  public PickOrder(final String id) {
    this.id = id;
  }

  // ----------------------------------------------------------------------------

  public String getId() {
    return id;
  }

  public List<PickLine> getPickLines() {
    return Collections.unmodifiableList(pickLines);
  }

  public void setPutLocationCode(final String putLocationCode) {
    this.putLocationCode = putLocationCode;
  }

  public String getPutLocationCode() {
    return putLocationCode;
  }

  // ----------------------------------------------------------------------------

  public void addPickLine(final PickLine pickLine) {
    pickLines.add(pickLine);
  }

  // ----------------------------------------------------------------------------

  @Override
  public String toString() {
    return "PickOrder[" + id + ":" + pickLines + "=>" + putLocationCode + "]";
  }

  // ----------------------------------------------------------------------------
}
