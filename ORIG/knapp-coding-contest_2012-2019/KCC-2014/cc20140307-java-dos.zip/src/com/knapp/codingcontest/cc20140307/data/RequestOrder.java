/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RequestOrder {
  private final String orderId;
  private final List<RequestLine> requestLines = new ArrayList<RequestLine>();

  // ----------------------------------------------------------------------------

  public RequestOrder(final String orderId) {
    this.orderId = orderId;
  }

  // ----------------------------------------------------------------------------

  public String getOrderId() {
    return orderId;
  }

  public List<RequestLine> getRequestLines() {
    return Collections.unmodifiableList(requestLines);
  }

  // ----------------------------------------------------------------------------

  public void addRequestLine(final RequestLine requestLine) {
    requestLines.add(requestLine);
  }

  // ----------------------------------------------------------------------------

  @Override
  public String toString() {
    return "RequestOrder[" + orderId + ":" + requestLines + "]";
  }
}
