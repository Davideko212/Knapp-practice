/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PickOrderCollection {
  private final List<PickOrder> pickOrders = new ArrayList<PickOrder>();

  // ----------------------------------------------------------------------------

  public List<PickOrder> getPickOrders() {
    return Collections.unmodifiableList(pickOrders);
  }

  public void addPickOrder(final PickOrder pickOrder) {
    pickOrders.add(pickOrder);
  }

  // ----------------------------------------------------------------------------

  @Override
  public String toString() {
    return "PickOrders[" + pickOrders + "]";
  }

  // ----------------------------------------------------------------------------
}
