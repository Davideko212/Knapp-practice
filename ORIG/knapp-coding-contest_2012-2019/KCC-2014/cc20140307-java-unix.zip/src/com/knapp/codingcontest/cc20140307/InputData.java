/* -*- java -*- ************************************************************************** *
 *
 *            Copyright (C) Knapp Logistik Automation GmbH
 *
 *   The copyright to the computer program(s) herein is the property
 *   of Knapp.  The program(s) may be used   and/or copied only with
 *   the  written permission of  Knapp  or in  accordance  with  the
 *   terms and conditions stipulated in the agreement/contract under
 *   which the program(s) have been supplied.
 *
 * *************************************************************************************** */

package com.knapp.codingcontest.cc20140307;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import com.knapp.codingcontest.cc20140307.data.PickLocation;
import com.knapp.codingcontest.cc20140307.data.PutLocation;
import com.knapp.codingcontest.cc20140307.data.RequestLine;
import com.knapp.codingcontest.cc20140307.data.RequestOrder;

public class InputData {
  private static DateFormat DATE_FORMAT_EXPIRY_DATE = new SimpleDateFormat("yyyy-MM-dd");

  // ----------------------------------------------------------------------------

  private final String dataPath;
  private final Collection<PutLocation> putLocations = new ArrayList<PutLocation>();
  private final Collection<PickLocation> pickLocations = new ArrayList<PickLocation>();
  private final Collection<RequestOrder> requestOrders = new ArrayList<RequestOrder>();

  // ----------------------------------------------------------------------------

  public InputData(final String dataPath) {
    this.dataPath = dataPath;
  }

  // ----------------------------------------------------------------------------

  public void readData() throws IOException {
    putLocations.addAll(readPutLocations());
    pickLocations.addAll(readPickLocations());
    requestOrders.addAll(readRequestOrders());
  }

  // ----------------------------------------------------------------------------

  public Collection<PutLocation> getPutLocations() {
    return Collections.unmodifiableCollection(putLocations);
  }

  public Collection<PickLocation> getPickLocations() {
    return Collections.unmodifiableCollection(pickLocations);
  }

  public Collection<RequestOrder> getRequestOrders() {
    return Collections.unmodifiableCollection(requestOrders);
  }

  // ----------------------------------------------------------------------------

  private Collection<PutLocation> readPutLocations() throws IOException {
    final Collection<PutLocation> putLocations_ = new ArrayList<PutLocation>();
    final Reader fr = new FileReader(fullFileName("put-locations.csv"));
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(fr);
      for (String line = reader.readLine(); line != null; line = reader.readLine()) {
        // loc-code;loc-x;loc-y;
        final String[] columns = splitCsv(line);

        final String locationCode = columns[0];
        final String x_ = columns[1];
        final String y_ = columns[2];

        putLocations_.add(new PutLocation(locationCode, Integer.parseInt(x_), Integer.parseInt(y_)));
      }
      return putLocations_;
    } finally {
      close(reader);
      close(fr);
    }
  }

  // ----------------------------------------------------------------------------

  private Collection<PickLocation> readPickLocations() throws IOException {
    final Collection<PickLocation> pickLocations_ = new ArrayList<PickLocation>();
    final Reader fr = new FileReader(fullFileName("pick-locations.csv"));
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(fr);
      for (String line = reader.readLine(); line != null; line = reader.readLine()) {
        // loc-code;loc-x;loc-y;product-code;product-expiry-date;product-stock-quantity;
        final String[] columns = splitCsv(line);

        final String locationCode = columns[0];
        final String x_ = columns[1];
        final String y_ = columns[2];

        final String productCode = columns[3];
        final String expiryDate_ = columns[4];
        final String stockQuantity_ = columns[5];

        pickLocations_.add(new PickLocation(locationCode, Integer.parseInt(x_), Integer.parseInt(y_), //
            productCode, makeDate(expiryDate_), Integer.parseInt(stockQuantity_)));
      }
      return pickLocations_;
    } finally {
      close(reader);
      close(fr);
    }
  }

  private Date makeDate(final String date_) throws IOException {
    synchronized (InputData.DATE_FORMAT_EXPIRY_DATE) {
      try {
        return InputData.DATE_FORMAT_EXPIRY_DATE.parse(date_);
      } catch (final ParseException exception) {
        throw new IOException("failed to parse date: " + date_, exception);
      }
    }
  }

  // ----------------------------------------------------------------------------

  private Collection<RequestOrder> readRequestOrders() throws IOException {
    final Collection<RequestOrder> orderRequests_ = new ArrayList<RequestOrder>();
    final Reader fr = new FileReader(fullFileName("request-orders.csv"));
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(fr);
      for (String line = reader.readLine(); line != null; line = reader.readLine()) {
        // ord-id;(prod-code;req-quantity;)*
        final String[] columns = splitCsv(line);

        final String orderId = columns[0];
        final RequestOrder orderRequest = new RequestOrder(orderId);
        for (int i = 1; i < columns.length; i += 2) {
          final String productCode = columns[i + 0];
          final String requestedQuantity_ = columns[i + 1];
          orderRequest.addRequestLine(new RequestLine(productCode, Integer.parseInt(requestedQuantity_)));
        }
        orderRequests_.add(orderRequest);
      }
      return orderRequests_;
    } finally {
      close(reader);
      close(fr);
    }
  }

  // ----------------------------------------------------------------------------

  private File fullFileName(final String fileName) {
    final String fullFileName = dataPath + File.separator + fileName;
    return new File(fullFileName);
  }

  private void close(final Closeable closeable) {
    if (closeable != null) {
      try {
        closeable.close();
      } catch (final IOException exception) {
        exception.printStackTrace(System.err);
      }
    }
  }

  // ----------------------------------------------------------------------------

  private String[] splitCsv(final String line) {
    return line.split(";");
  }
}
