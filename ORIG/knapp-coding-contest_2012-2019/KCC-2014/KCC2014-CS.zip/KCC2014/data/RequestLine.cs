﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// A request line - an item that should be picked and shipped from the warehouse
    /// </summary>
    [DebuggerDisplay("RequestLine {ProductCode} [{RequestedQuantity}]")]
    public class RequestLine
    {
        /// <summary>
        /// Get the productCode that should be picked/ shipped
        /// </summary>
        public string ProductCode { get; private set; }

        /// <summary>
        /// Get the number of items that should be picked/ shipped
        /// </summary>
        public int RequestedQuantity { get; private set; }

        /// <summary>
        /// Create a RequestLine
        /// </summary>
        /// <param name="productCode">product-code to pick/ ship</param>
        /// <param name="requestedQuantity">number of items to pick/ship</param>
        public RequestLine( string productCode, int requestedQuantity )
        {
            #if __SG_CONTRACTS               
            Contract.Requires( false == string.IsNullOrWhiteSpace( productCode ), "productCode is mandatory but is null or whitespace" );
            Contract.Requires( requestedQuantity >= 0, "requestedQuantity must be more than or equal to 0" );
            #endif

            this.ProductCode = productCode;
            this.RequestedQuantity = requestedQuantity;
        }


        /// <summary>
        /// Create a RequestLine
        /// </summary>
        /// <param name="productCode">product-code to pick/ ship</param>
        /// <param name="requestedQuantity">number of items to pick/ship</param>
        public RequestLine( string productCode, string requestedQuantity )
            : this ( productCode, int.Parse( requestedQuantity ) )
        {}

        /// <summary>
        /// Get string representing this instance
        /// </summary>
        /// <returns>string representing this instance</returns>
        public override string ToString( )
        {
            return string.Format( "{0} - {1} Stk"
                                    , ProductCode
                                    , RequestedQuantity
                                    );
        }
    }
}
