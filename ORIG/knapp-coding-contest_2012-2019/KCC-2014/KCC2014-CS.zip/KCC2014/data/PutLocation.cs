﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// Location where a pick-order can be stored after processing
    /// </summary>
    [DebuggerDisplay("PutLocation {Code} @ {X}, {Y}")]
    public class PutLocation : Location
    {
        /// <summary>
        /// Create a put-location from the given arguments
        /// </summary>
        /// <param name="dataAsArray">arguments as string array [locacionCode, X, Y]</param>
        public PutLocation( string[ ] dataAsArray )
            : base( dataAsArray[0], dataAsArray[1], dataAsArray[2] )
        { }

        /// <summary>
        /// Get a string representing this instance
        /// </summary>
        /// <returns>string representing this instance</returns>
        public override string ToString( )
        {
            return string.Format( "PutLocation {0}", base.ToString( ) );
        }
    }
}
