﻿using com.knapp.KCC2014.data;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// Order as it will be prepared in the warehouse
    /// </summary>
    [DebuggerDisplay("PickOrder {Id}[{PickLineCount} lines] --> {PutLocationCode}")]
    public class PickOrder
    {
        private readonly List<PickLine> pickLines = new List<PickLine>( );

        /// <summary>
        /// Get the unique identifier of this pick order
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Gets or sets the final location where this order will be placed after processing
        /// </summary>
        public string PutLocationCode { get; set; }

        /// <summary>
        /// Get the current number of pick-lines in this pick-order
        /// </summary>
        public int PickLineCount
        {
            get
            {
                return pickLines.Count( );
            }
        }

        /// <summary>
        /// Create an warehouse pick-order
        /// </summary>
        /// <param name="id">unique identifier of this order (same as request-order!)</param>
        /// <param name="putLocationCode">[opt] the final location of this pick-order after processing</param>
        public PickOrder( string id, string putLocationCode = "" )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != id, "id mandatory but is null" );
            Contract.Requires( false == string.IsNullOrWhiteSpace( id ), "id is mandatory but is empty" );
            #endif

            this.Id = id;
            this.PutLocationCode = putLocationCode;
        }

        /// <summary>
        /// Add a pick line (where and how many to pick) to this pick-order
        /// </summary>
        /// <param name="pickLine">pick-line to add to this order</param>
        public void AddPickLine( PickLine pickLine )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != pickLine, "pickLine is mandatory but is null" );
            #endif

            pickLines.Add( pickLine );
        }

        /// <summary>
        /// Return a read-only list of all pick-lines currently in this order
        /// </summary>
        /// <returns></returns>
        public IReadOnlyList<PickLine> GetPickLines( )
        {
            return pickLines.AsReadOnly( );
        }

        /// <summary>
        /// Get a string representing this pick-order 
        /// </summary>
        /// <returns>string representing this pick-order</returns>
        public override string ToString( )
        {
            return string.Format( "PickOrder [{0}]: {1} lines --> {2}"
                                , Id
                                , pickLines.Count
                                , PutLocationCode);
        }
    }
}
