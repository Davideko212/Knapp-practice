﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// Pickline representing a pick activity
    /// (where, what and how many to pick)
    /// </summary>
    [DebuggerDisplay("PickLine {ProductCode}[{NeededQuantity}] <-- {PickLocationCode}")]
    public class PickLine
    {
        /// <summary>
        /// Get the product code that will be picked
        /// </summary>
        public string ProductCode { get; private set; }
        
        /// <summary>
        /// Get the location code from which will be picked
        /// </summary>
        public string PickLocationCode { get; private set; }

        /// <summary>
        /// Get the number of items that will be picked
        /// </summary>
        public int NeededQuantity { get; private set; }

        /// <summary>
        /// Create a pickline with the given arguments
        /// </summary>
        /// <param name="productCode">product to pick</param>
        /// <param name="pickLocation">from where to pick</param>
        /// <param name="neededQuantity">how many to pick</param>
        public PickLine( string productCode, string pickLocationCode, int neededQuantity )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != productCode, "productCode mandatory but is null" );
            Contract.Requires( false == string.IsNullOrWhiteSpace( productCode ), "productCode is mandatory but is empty" );

            Contract.Requires( null != pickLocationCode, "pickLocationCode mandatory but is null" );
            Contract.Requires( false == string.IsNullOrWhiteSpace( pickLocationCode ), "pickLocationCode is mandatory but is empty" );
            #endif


            this.ProductCode = productCode;
            this.PickLocationCode = pickLocationCode;
            this.NeededQuantity = neededQuantity;
        }

        /// <summary>
        /// Get a string representation of this pick-line
        /// </summary>
        /// <returns></returns>
        public override string ToString( )
        {
            return string.Format( "PickLine: {0}[{1}] <--{2}"
                                , ProductCode
                                , NeededQuantity
                                , PickLocationCode );
        }
    }
}
