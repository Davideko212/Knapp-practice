﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.knapp.KCC.data
{
    public interface IEventData
    {
    }
}
