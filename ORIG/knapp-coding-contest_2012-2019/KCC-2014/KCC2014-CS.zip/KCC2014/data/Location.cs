﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// Base class for locations
    /// A location is a named and locatable physical space in the warehouse that can hold goods
    /// </summary>
    public abstract class Location
    {
        /// <summary>
        /// Get the code (únique name) of the location
        /// </summary>
        public string Code { get; private set; }
        
        /// <summary>
        /// Get the physical X-position of the location
        /// </summary>
        public int X { get; private set; }

        /// <summary>
        /// Get the physical Y-position of the location
        /// </summary>
        public int Y { get; private set; }

        /// <summary>
        /// Create a location from the given arguments
        /// </summary>
        /// <param name="code">code of the location</param>
        /// <param name="x">physical x-position</param>
        /// <param name="y">physical y-position</param>
        public Location(  string code,  string x,  string y )
            : this( code, int.Parse( x ), int.Parse( y ) )
        {}

        public Location( string code, int x, int y )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != code, "code is mandatory but is null");
            Contract.Requires( String.IsNullOrWhiteSpace( code ), "code is mandatory but is empty" );
            Contract.Ensures( this.Code.Equals( code ), "this.Code not set" );
            #endif

            this.Code = code;
            this.X = x;
            this.Y = y;
        }

        /// <summary>
        /// Get a string representation of this instance
        /// </summary>
        /// <returns>string representation of thi sinstance</returns>
        public override string ToString( )
        {
            return string.Format( "{0} @{1},{2}"
                                , Code
                                , X
                                , Y 
                                );
        }
    }
}
