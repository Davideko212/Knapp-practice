﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// 
    /// </summary>
    [DebuggerDisplay("PickLocation {Code} @{X},{Y} : {ProductCode} [{StockQuantity}]")]
    public class PickLocation : Location
    {
        /// <summary>
        /// Get the unique name of the product that is stored in this locatin
        /// </summary>
        public string ProductCode { get; private set; }

        /// <summary>
        /// Get the expiration date of the stock stored in this location
        /// </summary>
        public DateTime ExpirationDate { get; private set; }

        /// <summary>
        /// Get the number of items initially stored in this location
        /// </summary>
        public int StockQuantity { get; private set; }


        /// <summary>
        /// Create a pick-location from the given arguments
        /// </summary>
        /// <param name="dataAsString">data for instance as string [locationCode, X, Y, productCode, ExpirationDate, qty]</param>
        public PickLocation( string[ ] dataAsString )
            : this( dataAsString[0]
                    , int.Parse( dataAsString[1] )
                    , int.Parse( dataAsString[2] )
                    , dataAsString[3]
                    , DateTime.Parse( dataAsString[4] )
                    , int.Parse( dataAsString[5] ) )
        {}

        /// <summary>
        /// Create a pick-location from the given arguments
        /// </summary>
        public PickLocation( string locationCode, int x, int y, string productCode, DateTime expirationDate, int stockQuantity )
            : base( locationCode, x, y )
        {
            #if __SG_CONTRACTS
            Contract.Requires( false == string.IsNullOrWhiteSpace(productCode), "product code mandatory but is null or whitespace");
            Contract.Requires( null != expirationDate, "expirationDate mandator but is null" );
            Contract.Requires( stockQuantity >= 0, "stock qty must be larger than or equal to 0" );
            #endif

            this.ProductCode = productCode;
            this.ExpirationDate = expirationDate;
            this.StockQuantity = stockQuantity;
        }

        /// <summary>
        /// Get a string representing this pick-location instance
        /// </summary>
        /// <returns>string representing this pick-location instance</returns>
        public override string ToString( )
        {
            return string.Format( "PickLocation {0} - {1} ({2}) [{3}]"
                                    , base.ToString( )
                                    , ProductCode
                                    , ExpirationDate.ToString( "yyyy-MM-dd" )
                                    , StockQuantity
                                    );
        }
    }
}
