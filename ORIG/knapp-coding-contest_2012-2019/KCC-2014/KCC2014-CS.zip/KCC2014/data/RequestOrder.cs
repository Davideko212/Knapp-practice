﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// AN order that should be processed in the warehouse
    /// </summary>
    [DebuggerDisplay("RequestOrder {Id} - {LineCount} lines")]
    public class RequestOrder
    {
        /// <summary>
        /// Unique identifier of this order
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Number of lines in this order
        /// </summary>
        public int LineCount
        {
            get
            {
                return requestLines.Count( );
            }
        }

        private readonly List<RequestLine> requestLines = new List<RequestLine>( );

        /// <summary>
        /// Create an order with the given id
        /// </summary>
        /// <param name="id">unique identifier of this order</param>
        public RequestOrder( string id )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != id, "id mandatory but is null" );
            Contract.Requires( false == String.IsNullOrWhiteSpace( id ), "id mandatory but is empty");
            #endif

            this.Id = id;
        }

        /// <summary>
        /// Unmodifiable lines (product/ quantity) of this order
        /// </summary>
        public IReadOnlyList<RequestLine> GetRequestLines( )
        {
            return requestLines.AsReadOnly( );
        }

        /// <summary>
        /// Add a line to the order
        /// </summary>
        /// <param name="requestLine"></param>
        public void AddRequestLine( RequestLine requestLine )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null!= requestLine, "request line mandatory but is null");
            #endif

            requestLines.Add( requestLine );
        }

        /// <summary>
        /// Get string representation for this instance
        /// </summary>
        /// <returns>string represenation for this instance</returns>
        public override string ToString( )
        {
            return string.Format( "RequestOrder {0} - {1} lines "
                                    , Id
                                    , requestLines.Count 
                                    );
        }
    }
}
