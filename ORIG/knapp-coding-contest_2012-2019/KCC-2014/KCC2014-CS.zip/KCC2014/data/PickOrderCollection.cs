﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.data
{
    /// <summary>
    /// A collection of pick-orders
    /// </summary>
    public class PickOrderCollection
    {
        private readonly List<PickOrder> pickOrders = new List<PickOrder>( );

        /// <summary>
        /// Add a pick-order to the colection
        /// </summary>
        /// <param name="pickOrder">pick-order to add</param>
        public void Add( PickOrder pickOrder )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != pickOrder, "pickOrder is mandatory but is null" );
            #endif

            pickOrders.Add( pickOrder );
        }

        /// <summary>
        /// Get a read-only list of all currently stored pick-orders
        /// </summary>
        /// <returns>a read-only list of all currently stored pick-orders</returns>
        public IReadOnlyList<PickOrder> GetPickOrders( )
        {
            return pickOrders.AsReadOnly( );
        }

        /// <summary>
        /// A string representing this collection
        /// </summary>
        /// <returns>string representing this collection</returns>
        public override string ToString( )
        {
            return string.Format( "PickOrderCollection: {0} orders", pickOrders.Count );
        }
    }
}
