﻿using com.knapp.KCC.util;
using com.knapp.KCC2014.data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014
{
    /// <summary>
    /// Input collection for the KCC2014
    /// 
    /// -- do not modify ---
    /// 
    /// </summary>
    public class Input
    {
        private readonly List<PickLocation> pickLocations = new List<PickLocation>();
        private readonly List<PutLocation> putLocations = new List<PutLocation>();
        private readonly List<RequestOrder> requestOrders = new List<RequestOrder>( );

        /// <summary>
        /// Create the input from the given directory
        /// </summary>
        /// <param name="dataPath">directory from which to load the data</param>
        public Input( string dataPath )
        {
            LoadData( dataPath );
        }

        /// <summary>
        /// Get all put-locations available in the warehouse
        /// </summary>
        /// <returns>read-only list with all put-locations</returns>
        public IReadOnlyList<PutLocation> GetPutLocations( )
        {
            return putLocations.AsReadOnly( );
        }

        /// <summary>
        /// Get all pick-locations available in this warehouse
        /// </summary>
        /// <returns>read-only list with all pick-locations</returns>
        public IReadOnlyList<PickLocation> GetPickLocations( )
        {
            return pickLocations.AsReadOnly();
        }

        public IReadOnlyList<RequestOrder> GetRequestOrders( )
        {
            return requestOrders.AsReadOnly();
        }

        /// <summary>
        /// Loads all data from the files in the data directory
        /// </summary>
        /// <param name="dataPath">directory from which to load the files</param>
        private void LoadData( string dataPath )
        {
            string sourceFílename = Path.Combine( dataPath, "put-locations.csv" );
            foreach( data.PutLocation putLocation in CsvReader.ReadCsvFile<PutLocation>( sourceFílename ) )
            {
                putLocations.Add( putLocation );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} put-locations", putLocations.Count );

            sourceFílename = Path.Combine( dataPath, "pick-locations.csv" );
            foreach ( data.PickLocation pickLocation in CsvReader.ReadCsvFile<PickLocation>( sourceFílename ) )
            {
                pickLocations.Add( pickLocation );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} pick-locations", pickLocations.Count );

            sourceFílename = Path.Combine( dataPath, "request-orders.csv" );
            foreach ( KCC2014.util.StringArrayContainer c in CsvReader.ReadCsvFile<KCC2014.util.StringArrayContainer>( sourceFílename ) )
            {
                RequestOrder currentOrder = new RequestOrder( c.Strings[ 0 ] );

                for ( int i = 1; i < c.Strings.Length; ++i )
                {
                    string productCode = c.Strings[ i ];
                    int stockQuantity = int.Parse( c.Strings[ ++i ] );
                    currentOrder.AddRequestLine( new RequestLine( productCode, stockQuantity ) );
                }

                requestOrders.Add( currentOrder );
            }

            System.Console.Out.WriteLine( "+++ loaded: {0} request-orders", requestOrders.Count );
        }
    }
}
