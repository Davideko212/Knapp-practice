﻿using com.knapp.KCC2014.data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014
{
    /// <summary>
    /// Output writer for the KCC2014
    /// 
    /// -- do not modify --
    /// 
    /// </summary>
    public class Output
    {
        private readonly string outPath;

        /// <summary>
        /// Create an output writer the writes the output files into the given directory
        /// </summary>
        /// <param name="outPath"></param>
        public Output( string outPath )
        {
            this.outPath = outPath;
        }

        /// <summary>
        /// Write the pick-orders into the given directory
        /// </summary>
        /// <param name="pickOrderCollection">collection containing all pickOrders created by OrderPlanning</param>
        /// <returns>number of pick orders written</returns>
        public int writeOutput( PickOrderCollection pickOrderCollection )
        {
            int orderCount = 0;
            using ( StreamWriter writer = new StreamWriter( Path.Combine( outPath, "pick-orders.csv" ), false ) )
            {
                foreach ( PickOrder pickOrder in pickOrderCollection.GetPickOrders( ) )
                {
                    writer.Write( "{0};{1};", pickOrder.Id, pickOrder.PutLocationCode );

                    foreach ( PickLine pickLine in pickOrder.GetPickLines( ) )
                    {
                        writer.Write( "{0};{1};", pickLine.PickLocationCode,pickLine.NeededQuantity );
                    }
                    writer.WriteLine( );

                    ++orderCount;
                }
                writer.WriteLine( );
                writer.Flush( );
            }

            return orderCount;
        }
    }
}
