﻿using com.knapp.KCC2014.data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014.OrderPlanning
{
    public class OrderPlanning
    {
        private readonly Input input;
        private readonly PickOrderCollection pickOrders = new PickOrderCollection( );

        /// <summary>
        /// Create an order-planner for the given input
        /// </summary>
        /// <param name="input">input containing put-lcoations, pick-locations and request-orders</param>
        public OrderPlanning( Input input )
        {
            this.input = input;
        }


        /// <summary>
        /// Create the pickorders
        /// see requirements doc for details
        /// 
        /// add the pickorders to the already given pickOrders list
        /// </summary>
        public void CreatePickOrders( )
        {
            ///TODO: Your code goes here and inserts into pickOrders
            ///TODO: Write your participant-id and your name to the properties file
        }

        /// <summary>
        /// Get the list of created pick-orders
        /// Used by the result writer
        /// </summary>
        /// <returns>the created pick-orders in a PickOrderCollection</returns>
        public PickOrderCollection GetPickOrders( )
        {
            return pickOrders;
        }
    }
}
