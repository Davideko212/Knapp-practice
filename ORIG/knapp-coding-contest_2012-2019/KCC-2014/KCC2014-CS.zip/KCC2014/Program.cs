﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2014
{
    /// <summary>
    /// Main for the KCC 2014 -the KNAPP Coding Contest 2014
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main function that will be executed
        /// 
        /// -- do not modify --
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main( string[ ] args )
        {
            System.Console.Out.WriteLine( "KNAPP Coding Contest 2014" );
            System.Console.Out.WriteLine( "Starting..." );

            System.Console.Out.WriteLine( "Loading data..." );
            Input input = new Input( @"input");

            System.Console.Out.WriteLine( "Executing... (YOUR code)" );
            OrderPlanning.OrderPlanning customCode = new OrderPlanning.OrderPlanning( input );
            customCode.CreatePickOrders( );
            System.Console.Out.WriteLine( "Finished executing... (YOUR code)" );

            System.Console.Out.WriteLine( "Writing result..." );

            Output output = new Output( @".\" );
            int pickOrdersWrittenCount = output.writeOutput( customCode.GetPickOrders( ) );
            System.Console.Out.WriteLine( "... wrote {0} pick-orders", pickOrdersWrittenCount);

            System.Console.Out.WriteLine( "Finished" );
            System.Console.Out.WriteLine( "Press any key to continue..." );
            System.Console.In.Read( );
        }
    }
}
