﻿using System.Diagnostics.Contracts;


namespace com.knapp.KCC2014.util
{
    /// <summary>
    /// Helper class to store string array in an instance
    /// </summary>
    public class StringArrayContainer
    {

        /// <summary>
        /// Returns the stored array
        /// </summary>
        public string[ ] Strings { get; private set; }

        /// <summary>
        /// Create an instance and store the given string array
        /// </summary>
        /// <param name="data">the string array to store</param>
        public StringArrayContainer( string[ ] data )
        {
            Contract.Requires( data != null, "data is mandatory but is null" );

            this.Strings = data;
        }
    }
}