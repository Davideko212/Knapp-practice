﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace com.knapp.KCC.util
{
    internal class CsvReader
    {

        /// <summary>
        ///  read lines from a CSV file, create instances of type Target by calling a string[] ctor
        /// </summary>
        /// <typeparam name="Target">type to create</typeparam>
        /// <param name="fullFileName">Full path to the csv file</param>
        /// <returns>a list of instances or a empty list</returns>
        public static List<Target> ReadCsvFile<Target>( string fullFileName )
            where Target : class
        {
            if( false == File.Exists( fullFileName ) )
            {
                throw new InvalidOperationException(string.Format("CSV-Input file does not exist: '{0}'", fullFileName ) );
            }

            ConstructorInfo ctorInfo = typeof( Target ).GetConstructor( new [] { typeof(string[]) } );

            if ( null == ctorInfo )
            {
                throw new InvalidOperationException( string.Format( "Target '{0}' can not be constructed because it does not contain a ctor with string [] as argument"
                    , typeof( Target).FullName ) );
            }


            List<Target> objects = new List<Target>();

            using (StreamReader streamReader = new StreamReader( fullFileName ))
            {
                string line;
                while ((line = streamReader.ReadLine() ) != null )
                {
                    string[] fields = line.Split( new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries );

                    Target t = (Target)ctorInfo.Invoke( new object[] { fields } );

                    objects.Add( t );
                }
            }


            return objects;
        }
    }
}
