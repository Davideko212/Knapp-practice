﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC.util
{
    public class WallClockTime : IComparable<WallClockTime>, IEquatable<WallClockTime>
    {

        public int MinuteOfTheDay { get; private set; }

        /// <summary>
        /// create a WallClockTime from a string in the format of (HH:mm)     00:00 - 23:59
        /// </summary>
        /// <param name="timeString">time of the day in HH:mm format, must be 5 long!</param>
        public WallClockTime( string timeString )
        {
            #if __SG_CONTRACTS
            Contract.Requires( 5 == timeString.Length, "given timeString is not 5 chars long" );
            #endif

            int hours = int.Parse(timeString.Substring( 0, 2 ));
            int minutes = int.Parse( timeString.Substring( 3,2) );

            #if __SG_CONTRACTS
            Contract.Assert( hours >= 0, string.Format( "hour argument invalid (below 0): '{0}'", timeString ) );
            Contract.Assert( hours < 24, string.Format( "hour argument invalid (above 23): '{0}'", timeString ) );
            Contract.Assert( minutes >= 0, string.Format( "minute argument invalid (below 0): '{0}'", timeString ) );
            Contract.Assert( minutes < 60, string.Format( "minute argument invalid (above 60): '{0}'", timeString ) );
            #endif

            MinuteOfTheDay = hours * 60 + minutes;
        }


        /// <summary>
        /// create a WallClockTime from the minutes of the day directly 0 - 1439
        /// </summary>
        /// <param name="MinuteOfTheDay"></param>
        public WallClockTime( int MinuteOfTheDay )
        {
            #if __SG_CONTRACTS
            Contract.Requires( MinuteOfTheDay >= 0, "MinuteOfTheDay below 0" );
            Contract.Requires( MinuteOfTheDay < 24*60, "MinuteOfTheDay larger than 1d 0" );
            #endif

            this.MinuteOfTheDay = MinuteOfTheDay;
        }

        /// <summary>
        /// create a WallClockTime from another WallClocTimeInstance
        /// </summary>
        /// <param name="other">the other WallClockTime to take the value from</param>
        public WallClockTime( WallClockTime other )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != other, "WallClockTime to copy from must not be null" );
            Contract.Requires( other.MinuteOfTheDay >= 0, "Other WallClockTime invalid (below 0)" );
            Contract.Requires( other.MinuteOfTheDay < 1440, "Other WallClockTime invalid (above 1440)" );
            #endif


            this.MinuteOfTheDay = other.MinuteOfTheDay;

            #if __SG_CONTRACTS
            Contract.Assert( MinuteOfTheDay >= 0, string.Format( "MinuteOfTheDay below 0: {0}", MinuteOfTheDay ) );
            Contract.Assert( MinuteOfTheDay < 24*60, string.Format( "MinuteOfTheDay larger than 1d 0: {0}", MinuteOfTheDay ) );
            #endif
        }


        /// <summary>
        /// Get the day time in HH:mm representation
        /// </summary>
        /// <returns>time of day in HH:mm representation</returns>
        public string ToHHmm()
        {
            if ( 0 == MinuteOfTheDay )
            {
                return "00:00";
            }

            return string.Format("{0:0#}:{1:0#}", MinuteOfTheDay / 60, MinuteOfTheDay % 60);
        }

        /// <summary>
        /// Get the day time in HH:mm representation
        /// </summary>
        /// <returns>time of day in HH:mm representation</returns>
        public override string ToString()
        {
 	        return ToHHmm();
        }

        /// <summary>
        /// Compare to WallCockTimes
        /// </summary>
        /// <param name="other">The WallClockTime to compare to</param>
        /// <returns></returns>
        public int CompareTo(WallClockTime other)
        {
            #if __SG_CONTRACTS
            Contract.Assert( null != other, "WallClockTime to compare with must not be null" );
            #endif

 	        return this.MinuteOfTheDay - other.MinuteOfTheDay;
        }

        /// <summary>
        /// get the next possible WallClockTime
        /// </summary>
        /// <returns>the next possible WallClockTime, null if not possible (>1d)</returns>
        public WallClockTime Next()
        {
            if (MinuteOfTheDay < 24*60)
            {
                return new WallClockTime( MinuteOfTheDay + 1 );
            }

            return null;
        }

        /// <summary>
        /// Less than operator
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns>true when left < right </returns>
        public static bool operator < ( WallClockTime left, WallClockTime right )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != left, "WallClockTime to compare must not be null (left)" );
            Contract.Requires( null != right, "WallClockTime to compare must not be null (right)" );
            #endif

            return left.MinuteOfTheDay < right.MinuteOfTheDay;
        }

        /// <summary>
        /// Provide larger than operator
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns>true when left > right</returns>
        public static bool operator > (WallClockTime left, WallClockTime right )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != left, "WallClockTime to compare must not be null (left)" );
            Contract.Requires( null != right, "WallClockTime to compare must not be null (right)" );
            #endif

            return left.MinuteOfTheDay > right.MinuteOfTheDay;
        }

        /// <summary>
        /// Check if two WallClockTimes are equal
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals( WallClockTime other )
        {
            #if __SG_CONTRACTS
            Contract.Assert( null != other, "WallClockTime to compare with must not be null" );
            #endif

            return this.MinuteOfTheDay == other.MinuteOfTheDay;
        }

        /// <summary>
        /// Check for equality with object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals( object obj )
        {
            if (obj is WallClockTime)
            {
                WallClockTime other = (WallClockTime)obj;

                return this.MinuteOfTheDay == other.MinuteOfTheDay;
            }

            return false;
        }

        /// <summary>
        /// Override GetHasCode
        /// </summary>
        /// <returns>key for equality (MinutesOfTheDay)</returns>
        public override int GetHashCode()
        {
            return MinuteOfTheDay;
        }
    }
}