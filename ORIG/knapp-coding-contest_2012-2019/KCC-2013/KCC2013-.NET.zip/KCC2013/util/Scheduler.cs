﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Configuration;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.util
{
    public class Scheduler : IDisposable
    {
        private Dictionary<WallClockTime, List<data.IEventData>> timedEvents = new Dictionary<WallClockTime, List<data.IEventData>>();

        private StreamWriter resultFileWriter;

        public Scheduler( string resultFilename )
        {
            resultFileWriter = new StreamWriter( resultFilename, false );
        }


        public void run( WallClockTime startTime
                       , WallClockTime endTime
                       , orderstart.OrderStart orderStart )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != startTime, "Argument startTime is required but is null" );
            Contract.Requires( endTime != null, "Argument endTime is required but is null" );
            Contract.Requires( null != orderStart, "Argument orderStart is required but is null" );
            #endif

            System.Console.Out.WriteLine("### Starting day @ {0}", startTime.ToHHmm() );

            for ( WallClockTime currentTime = new WallClockTime( startTime )
                 ;  currentTime < endTime
                 ; currentTime = currentTime.Next())
            {
                if (timedEvents.ContainsKey( currentTime ))
                {
                    data.IEventData lastData = default(data.IEventData);

                    try
                    {
                        foreach (data.IEventData eventData in timedEvents[ currentTime ])
                        {
                            lastData = eventData;

                            if (eventData is data.Instruction)
                            {
                                data.Instruction instruction = (data.Instruction)eventData;

                                if (instruction.InstructionType == data.InstructionType.Customer)
                                {
                                    orderStart.activateCustomer( currentTime, instruction.Code );
                                }
                                else if (instruction.InstructionType == data.InstructionType.Route)
                                {
                                    orderStart.activateRoute( currentTime, instruction.Code );
                                }
                            }
                            else if (eventData is data.Order)
                            {
                                orderStart.Received( currentTime, (data.Order)eventData );
                            }
                            else if (eventData is data.SubOrder)
                            {
                                orderStart.Received( currentTime, (data.SubOrder)eventData );
                            }
                            else if (eventData is data.PrintData)
                            {
                                orderStart.Received( currentTime, (data.PrintData)eventData );
                            }
                            else if (eventData is data.Route)
                            {
                                orderStart.Received( currentTime, (data.Route)eventData );
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        System.Console.Error.WriteLine( "!!! Exception in data preparation @ {0}", currentTime.ToHHmm() );
                        System.Console.Error.WriteLine( "   Data: {0}", lastData.ToString() );
                        System.Console.Error.WriteLine( "   {0}", e.GetType().FullName );
                        System.Console.Error.WriteLine( "   {0}", e.Message );
                        System.Console.Error.WriteLine( "   {0}", e.StackTrace );

                        throw;
                    }
                }

                try
                {
                    data.SubOrderKey subOrderToStart = orderStart.getNextSubOrderToStart( currentTime );

                    if (null != subOrderToStart)
                    {
                        archiveResult( currentTime, subOrderToStart );
                    }
                }
                catch (Exception e)
                {
                    System.Console.Error.WriteLine( "!!! Exception in getNextSubOrder @ {0}", currentTime.ToHHmm() );
                    System.Console.Error.WriteLine( "   {0}", e.GetType().FullName );
                    System.Console.Error.WriteLine( "   {0}", e.Message );
                    System.Console.Error.WriteLine( "   {0}", e.StackTrace );

                    throw;
                }
            }

            System.Console.Out.WriteLine( "### Ending day @ {0}", endTime.ToHHmm() );
        }

        /// <summary>
        /// Write the result of orderStart into the result file
        /// Format for file: HH:MM;OrderNr;SubOrderNr;
        /// </summary>
        /// <param name="time"></param>
        /// <param name="subOrder"></param>
        private void archiveResult( WallClockTime time, data.SubOrderKey subOrder )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != time, "Argument time is required but is null" );
            Contract.Requires( null != subOrder, "Argument subOrder is required but is null" );
            #endif

            string resultLine = string.Format("{0};{1};{2};"
                , time.ToHHmm()
                , subOrder.OrderNumber
                , subOrder.SubOrderNumber
                );

            resultFileWriter.WriteLine( resultLine );
            resultFileWriter.Flush();
        }

        /// <summary>
        /// add an event to the event - store at the specific time
        /// </summary>
        /// <param name="eventTime">time this event should occur</param>
        /// <param name="eventData">the event</param>
        public void AddEvent( WallClockTime eventTime, data.IEventData eventData )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != eventTime, "Argument eventTime is required but is null" );
            Contract.Requires( null != eventData, "Argument eventData is required but is null" );
            #endif

            if ( false == timedEvents.ContainsKey( eventTime  ) )
            {
                timedEvents.Add( eventTime, new List<data.IEventData>() );  
            }


            timedEvents[ eventTime ].Add( eventData );
        }


        public void Dump()
        {
            foreach (WallClockTime time in timedEvents.Keys)
            {
                System.Console.Out.WriteLine("@{0}: {1} events"
                                        , time.ToHHmm()
                                        , timedEvents[ time ].Count 
                                        );

                foreach (var e in timedEvents[ time ])
                {
                    System.Console.Out.WriteLine( "       {0}", e.ToString() );
                }
            }
        }

        protected virtual void Dispose( bool disposing )
        {
            if (null != resultFileWriter)
            {
                resultFileWriter.Flush();
                resultFileWriter.Close();
                resultFileWriter = null;
            }
        }

        public void Dispose()
        {
            Dispose( true );
        }
    }
}
