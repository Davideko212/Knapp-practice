﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using com.knapp.KCC2013;

namespace KCC2013
{
    static class Program
    {
        private static KCC2013Main kcc2013Main = new KCC2013Main();

        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main()
        {
            System.Console.Out.WriteLine( "KNAPP Coding Contest 2013" );
            System.Console.Out.WriteLine( "Starting..." );

            System.Console.Out.WriteLine( "Loading data..." );
            kcc2013Main.Setup();

            System.Console.Out.WriteLine( "Creating OrderStart..." );
            kcc2013Main.Prepare();

            System.Console.Out.WriteLine( "Executing..." );
            kcc2013Main.Execute();

            System.Console.Out.WriteLine( "Finished" );
        }
    }
}
