﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.data
{
    public sealed class SubOrderKey: IEquatable<SubOrderKey>
    {
        /// <summary>
        /// get or set the OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// get or set the SubOrderNumber
        /// </summary>
        public string SubOrderNumber { get; set; }


        /// <summary>
        /// Construct an instance with the given OrderNumber/ SubOrderNUmber
        /// </summary>
        /// <param name="OrderNumber">OrderNumber to set</param>
        /// <param name="SubOrderNumber">SubOrderNumber to set</param>
        public SubOrderKey( string OrderNumber, string SubOrderNumber )
        {
            #if __SG_CONTRACTS
            Contract.Requires( false == string.IsNullOrWhiteSpace( OrderNumber ), "Argument OrderNumber is required but is null or whitespace" );
            Contract.Requires( false == string.IsNullOrWhiteSpace( SubOrderNumber ), "Argument SubOrderNumber is required but is null or whitespace" );
            #endif

            this.OrderNumber = OrderNumber;
            this.SubOrderNumber = SubOrderNumber;
        }

        /// <summary>
        /// get a formatted string representation of this instance
        /// </summary>
        /// <returns>a formatted string representation of this instance: "SubOrderKey[OrderNUmber/ SubOrderNumber]"</returns>
        public override string ToString()
        {
            return string.Format("SubOrderKey[{0}/ {1}]"
                , OrderNumber
                , SubOrderNumber
                );
        }

        /// <summary>
        /// Check whether two SubOrderKeys are equal
        /// </summary>
        /// <param name="other"></param>
        /// <returns>true when both SubOrderKeys are equal (OrderNumber and SubOrderNumber)</returns>
        public bool Equals( SubOrderKey other )
        {
            #if __SG_CONTRACTS
            Contract.Assert( null != other, "Argument other is required but is null" );
            #endif

            return this.OrderNumber == other.OrderNumber
                && this.SubOrderNumber == other.SubOrderNumber;                   
        }

        /// <summary>
        /// Check whether SubOrderKey is equal to an other object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>true when both SubOrderKeys are equal (OrderNumber and SubOrderNumber)</returns>
        public override bool Equals( object obj )
        {
            #if __SG_CONTRACTS
            Contract.Assert( null != obj, "Argument obj is required but is null" );
            #endif

            if (obj is WallClockTime)
            {
                SubOrderKey other = (SubOrderKey)obj;

                return this.OrderNumber == other.OrderNumber
                && this.SubOrderNumber == other.SubOrderNumber;
            }

            return false;
        }

        /// <summary>
        /// Get the hashcode for this instance
        /// </summary>
        /// <returns>the hascode for this instance</returns>
        public override int GetHashCode()
        {
            return OrderNumber.GetHashCode() * 31 + SubOrderNumber.GetHashCode();
        }
    }
}
