﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.data
{
    public class PrintData : IEventData
    {
        /// <summary>
        /// get the SubOrderKey
        /// </summary>
        public SubOrderKey SubOrderKey { get; private set; }

        /// <summary>
        /// get the time this event occurs
        /// </summary>
        internal WallClockTime EventTime { get; private set; }

        /// <summary>
        /// construct an instance from the given data array
        /// </summary>
        /// <param name="fields">string array three long (event-time, ordernumber, subordernumber)</param>
        public PrintData( string[] fields )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != fields, "Argument fields is required but is null" );
            Contract.Requires( 3 == fields.Length, "Argument fields must have a Length of 3" );
            #endif

            EventTime = new WallClockTime( fields[ 0 ].Trim() );

            SubOrderKey = new SubOrderKey( fields[ 1 ].Trim(), fields[ 2 ].Trim() );
        }

        public override string ToString()
        {
            return string.Format( "PrintData[{0}]", SubOrderKey.ToString() );
        }
    }
}
