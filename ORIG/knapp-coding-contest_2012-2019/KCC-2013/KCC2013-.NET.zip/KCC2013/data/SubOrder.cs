﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.data
{
    public class SubOrder : IEventData
    {

        /// <summary>
        /// get the subOrderKey
        /// </summary>
        public SubOrderKey SubOrderKey { get; private set; }


        /// <summary>
        /// geth the flag whether printdata is required
        /// </summary>
        public bool NeedsPrintData { get; private set; }

        /// <summary>
        /// get the time this suborder takes to be processed in warehouse
        /// </summary>
        public int ProcessingTime { get; private set; }

        /// <summary>
        /// get the time this SubOrderData shall occur
        /// </summary>
        internal WallClockTime EventTime { get; private set; }

        /// <summary>
        /// construct a SubOrderData from a string array
        /// Fields: EventTime, OrderNumber, SubOrderNumber, NeedsPrintData, ProcessingTime
        /// </summary>
        /// <param name="fields">the array holding all information</param>
        public SubOrder( string[] fields )
        {
            #if __SG_CONTRACTS
            Contract.Requires( null != fields, "Argument fields is required but is null" );
            Contract.Requires( 5 == fields.Length, "Argument fields must have a length of 5" );
            #endif

            EventTime = new WallClockTime( fields[ 0 ].Trim() );
            SubOrderKey = new SubOrderKey( fields[ 1 ].Trim(), fields[ 2 ].Trim() );
            NeedsPrintData = Boolean.Parse( fields[ 3 ].Trim() );
            ProcessingTime = int.Parse( fields[ 4 ].Trim() );
        }

        /// <summary>
        /// provide a string representation of this SubOrderData
        /// </summary>
        /// <returns>a string representation of this SubOrderData</returns>
        public override string ToString()
        {
            return string.Format( "SubOrder:[{0}, {1}, ProcessingTime={2}]"
                , SubOrderKey.ToString()
                , NeedsPrintData ? "needs printdata" : "no printdata required"
                , ProcessingTime
                );            
        }
    }
}
