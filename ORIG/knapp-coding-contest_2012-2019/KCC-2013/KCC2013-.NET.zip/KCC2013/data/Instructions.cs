﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.data
{
    public enum InstructionType { Route, Customer, Undefined = 0};

    public class Instruction : IEventData
    {

        /// <summary>
        /// get the type of this instruction
        /// </summary>
        public InstructionType InstructionType { get; private set; }

        /// <summary>
        /// get the code (key) for this instruction
        /// </summary>
        public string Code { get; private set; }

        /// <summary>
        /// get the time this instruction will be executed
        /// </summary>
        internal WallClockTime EventTime { get; private set; }

        /// <summary>
        /// Create an Instruction from an array of string values
        /// Format: HH:MM;(Customer|Route);Code;
        /// </summary>
        /// <param name="fields"></param>
        public Instruction( string[] fields )
        {
            #if __SG_CONTRACT
            Contract.Requires( null != fields, "Argument fields is required but is null" );
            Contract.Requires( 3 == fields.Length );
            #endif

            EventTime = new WallClockTime( fields[ 0 ].Trim() );
            Code = fields[ 2 ].Trim();

            InstructionType = (InstructionType)Enum.Parse( typeof( InstructionType ), fields[ 1 ].Trim() );
        }

        /// <summary>
        /// get a string representation of this Instruction
        /// </summary>
        /// <returns>a string representation of this Instruction</returns>
        public override string ToString()
        {
            return String.Format("Instruction[ enable {0}: {1}]"
                , InstructionType
                , Code 
                );
        }
    }
}
