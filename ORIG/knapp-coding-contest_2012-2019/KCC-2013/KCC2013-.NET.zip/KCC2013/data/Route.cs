﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.knapp.KCC2013.data
{
    /// <summary>
    /// reprents a route information
    /// </summary>
    public class Route : IEventData
    {
        /// <summary>
        /// get the route code
        /// </summary>
        public string RouteCode { get; private set; }

        /// <summary>
        /// get the departuretime
        /// </summary>
        public WallClockTime DepartureTime { get; private set; }

        /// <summary>
        /// construct a route from a given set of fields
        /// fields must be in the following order and format: Code;HH:MM;
        /// </summary>
        /// <param name="fields"></param>
        public Route( string[] fields )
        {
            RouteCode = fields[ 0 ].Trim();
            DepartureTime = new WallClockTime( fields[ 1 ].Trim() );
        }

        /// <summary>
        /// get a string representation of this route
        /// </summary>
        /// <returns>a string representation of this route</returns>
        public override string ToString()
        {
            return string.Format("Route[{0} @{1}]", RouteCode, DepartureTime.ToHHmm() );
        }
    }
}
