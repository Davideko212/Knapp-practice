﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013.data
{
    /// <summary>
    /// Represents an order header
    /// </summary>
    public class Order : IEventData
    {
        /// <summary>
        ///  get the OrderNumber
        /// </summary>
        public string OrderNumber { get; private set; }

        /// <summary>
        /// get the customer code
        /// </summary>
        public string CustomerCode { get; private set; }

        /// <summary>
        /// get the route code
        /// </summary>
        public string RouteCode { get; private set; }

        /// <summary>
        /// get the nukmber of sub-orders
        /// </summary>
        public int SubOrderCount { get; private set; }

        /// <summary>
        /// get the event time for this order header
        /// </summary>
        internal WallClockTime EventTime { get; private set; }

        /// <summary>
        /// construct an Order from a given set of fields
        /// fields must be in the following order and format: HH:MM;OrderNr;CustomerCode;TourCode;#SubOrders;
        /// </summary>
        /// <param name="fields"></param>
        public Order( string[] fields )
        {
            #if __SG_CONTRACTS
            Contract.Requires( 5 == fields.Length, "to few data fields, expected 5" );
            #endif

            EventTime = new WallClockTime( fields[0].Trim());
            OrderNumber = fields[ 1 ].Trim();
            CustomerCode = fields[ 2 ].Trim();
            RouteCode = fields[ 3 ].Trim();
            SubOrderCount = int.Parse( fields[ 4 ] );

            #if __SG_CONTRACTS
            Contract.Assert( false == string.IsNullOrWhiteSpace( OrderNumber ), "OrderNumber may not be null or whitespace only" );
            Contract.Assert( false == string.IsNullOrWhiteSpace( CustomerCode ), "CustomerCode may not be null or whitespace only" );
            Contract.Assert( false == string.IsNullOrWhiteSpace( RouteCode ), "RouteCode may not be null or whitespace only" );
            Contract.Assert( SubOrderCount  > 0, "SubOrderCount must be larger than 0" );
            #endif
        }

        /// <summary>
        /// get a string representation of this order
        /// </summary>
        /// <returns>a string representation of this order</returns>
        public override string ToString()
        {
            return string.Format("Order[OrderNumber={0}, CustomerCode={1}, RouteCode= {2}, NumberOfSubOrders={3}]"
                                    , OrderNumber
                                    , CustomerCode
                                    , RouteCode
                                    , SubOrderCount 
                                    );
        }
    }
}
