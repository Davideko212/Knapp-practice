﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.knapp.KCC2013.data;

namespace com.knapp.KCC2013.orderstart
{
    public class OrderStart
    {

        /// <summary>
        /// store for all routes
        /// </summary>
        private Dictionary<string, Route> routes = new Dictionary<string, Route>();

        /// <summary>
        /// default ctor
        /// 
        /// MUST BE AVAILABLE, NO OTHER CTOR WILL BE CALLED
        /// 
        /// Fell free to add code
        /// </summary>
        public OrderStart()
        { }

        /// <summary>
        /// all routes will be inserted before any other event
        /// </summary>
        /// <param name="route">route instance to add</param>
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void Received( WallClockTime currentTime, Route route )
        {
            routes.Add( route.RouteCode, route );
            /// Fell free to add code
        }

        // ----------------------------------------------------------------------------
        // (data-) events can occur multiple times within each cycle

        /// <summary>
        /// Handle the receipt of an order
        /// </summary>
        /// <param name="order">instance of the order that has been received</param>
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void Received( WallClockTime currentTime, Order order )
        {
            // TODO: update internal state/data
        }

        /// <summary>
        /// Handle the receipt of a sub-order
        /// </summary>
        /// <param name="subOrder">instance of the subOrder that has been received</param>
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void Received( WallClockTime currentTime, SubOrder subOrder )
        {
            // TODO: update internal state/data
        }

        /// <summary>
        /// Handle the receipt of printing data
        /// </summary>
        /// <param name="printData">instance of the subOrder that has been received</param>
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void Received( WallClockTime currentTime, PrintData printData )
        {
            // TODO: update internal state/data
        }
    
        /// <summary>
        /// activation will be done only once for a customer (no deactivation)
        /// </summary>
        /// <param name="customerCode"></param> 
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void activateCustomer( WallClockTime currentTime, String customerCode ) 
        {
        // TODO: update internal state/data
        }

        /// <summary>
        /// activation will be done only once for a route (no deactivation)
        /// </summary>
        /// <param name="routeCode"></param> 
        /// <param name="currentTime">the time when the function is called</param>
        public virtual void activateRoute( WallClockTime currentTime, String routeCode )
        {
            // TODO: update internal state/data
        }

        // ----------------------------------------------------------------------------
        /// <summary>
        /// this will get called exactly once per cycle and should return
        /// the next sub-order to start at <currentTime> - or <null> if none available
        /// </summary>
        /// <param name="currentTime">current time of day</param>
        /// <returns>the next order to start or null if none available</returns>
        public virtual SubOrderKey getNextSubOrderToStart(WallClockTime currentTime) 
       {
          // TODO: find next sub-order to start
         return null;
       }
    }
}
