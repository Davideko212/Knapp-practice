﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.knapp.KCC2013.util;
using System.Configuration;

#if __SG_CONTRACTS
using System.Diagnostics.Contracts;
#endif

namespace com.knapp.KCC2013
{
    public class KCC2013Main : IDisposable
    {
        private orderstart.OrderStart orderStartInstance;

        private Scheduler scheduler;

        /// <summary>
        /// create instance and check configuration in app.config
        /// </summary>
        public KCC2013Main()
        {
            #if __SG_CONTRACTS
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "resultFilename" ) );
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "orderFilename" ) );
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "subOrderFilename" ) );
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "printDataFilename" ) );
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "routeFilename" ) );
            Contract.Assert( ConfigurationManager.AppSettings.AllKeys.Contains<string>( "instructionFilename" ) );
            #endif
        }

        /// <summary>
        /// remove an existing output file
        /// load all event data
        /// </summary>
        public void Setup()
        {
            System.IO.File.Delete( ConfigurationManager.AppSettings[ "resultFilename" ] );

            scheduler =  new Scheduler( ConfigurationManager.AppSettings[ "resultFilename" ] );

            //load all data
            foreach (data.Route route in CsvReader.ReadCsvFile<data.Route>( ConfigurationManager.AppSettings[ "routeFilename" ] ))
            {
                scheduler.AddEvent( new WallClockTime( "07:59" ), route );
            }

            foreach (data.Order order in CsvReader.ReadCsvFile<data.Order>( ConfigurationManager.AppSettings[ "orderFilename" ] ))
            {
                scheduler.AddEvent( order.EventTime, order );
            }

            foreach (data.SubOrder subOrder in CsvReader.ReadCsvFile<data.SubOrder>( ConfigurationManager.AppSettings[ "subOrderFilename" ] ) )
            {
                scheduler.AddEvent( subOrder.EventTime, subOrder );
            }

            foreach (data.PrintData printData in CsvReader.ReadCsvFile<data.PrintData>( ConfigurationManager.AppSettings[ "printDataFilename" ] ))
            {
                scheduler.AddEvent( printData.EventTime, printData );
            }

            foreach (data.Instruction instruction in CsvReader.ReadCsvFile<data.Instruction>( ConfigurationManager.AppSettings[ "instructionFilename" ] ))
            {
                scheduler.AddEvent( instruction.EventTime, instruction );
            }
        }

        /// <summary>
        /// creates the instance of the OrderStart class
        /// </summary>
        public void Prepare()
        {
            try
            {
                orderStartInstance = new orderstart.OrderStart();
            }
            catch (Exception e)
            {
                System.Console.Error.WriteLine( "!!! Exception in ctor for OrderStart" );
                System.Console.Error.WriteLine( "   {0}", e.GetType().FullName );
                System.Console.Error.WriteLine( "   {0}", e.Message );
                System.Console.Error.WriteLine( "   {0}", e.StackTrace );

                throw;
            }
        }

        /// <summary>
        /// simulate the whole day
        /// </summary>
        public void Execute()
        {
            scheduler.run( new WallClockTime( "07:59" ), new WallClockTime( "17:00" ), orderStartInstance );
        }


        public void Dump()
        {
            scheduler.Dump();
        }

        protected virtual void Dispose( bool disposing )
        {
            if (null != scheduler)
            {
                scheduler.Dispose();
                scheduler = null;
            }
        }

        public void Dispose()
        {
            Dispose( true );
        }
    }
}
