﻿using System;
using System.Collections.Generic;
using System.IO;
using com.knapp.KCC2016.solution;
using com.knapp.KCC2016.util;

namespace com.knapp.KCC2016
{
    static class Program
    {
        static void Main( )
        {
            Input input = null;
            try
            {
                input = Input.CreateFromCsv( );

            }
            catch( Exception e )
            {
                ShowException( e, "Exception in startup code" );
                Console.Out.WriteLine( "Press <enter>" );
                Console.In.ReadLine( );
                Environment.Exit( -1 );
            }

            try
            {
                Console.Out.WriteLine( "### Your output starts here" );

                Solution solution = new Solution( input );

                WriteProperties(solution, Settings.OutputPath + Settings.outPropertyFilename);

                using (Scheduler scheduler = new Scheduler(input.ProductCollection
                    , input.PickOrderCollection
                    , input.LocationCollection
                    ))
                {

                    var result = scheduler.Run( solution) ;

                    using ( ResultWriter writer = new ResultWriter( Settings.OutputPath + Settings.outReplenFilename ) )
                    {
                        writer.Write( result );
                    }
                }
                Console.Out.WriteLine( "### Your output stops here" );

                PrepareUpload.CreateZipFile( );
                Console.Out.WriteLine( ">>> Created " + Settings.outZipFilename );
            }
            catch( Exception e )
            {
                ShowException( e, "Exception in application code" );
            }

            Console.Out.WriteLine( "Press <enter>" );
            Console.In.ReadLine( );
        }

        /// <summary>
        /// Helper function to write the properties to the file
        /// </summary>
        /// <param name="solution"></param>
        /// <param name="outFilename"></param>
        /// <exception cref="ArgumentException">when either solution.InstituteId or solution.ParticipantName is not valid</exception>
        private static void WriteProperties(Solution solution, string outFilename)
        {
            KContract.Requires<ArgumentException>( !string.IsNullOrWhiteSpace( solution.ParticipantName ), "solution.ParticipantName must not be empty - please set to correct value" );
            KContract.Requires<ArgumentException>( !string.IsNullOrWhiteSpace(solution.InstituteId), "solution.InstituteId must not be empty - please set to correct value");

            if (File.Exists(outFilename))
            {
                File.Delete( outFilename);
            }

            using (StreamWriter stream = new StreamWriter(outFilename))
            {
                stream.WriteLine( "# -*- conf-javaprop -*-" );
                stream.WriteLine( "participant = {0} {1}", solution.InstituteId, solution.ParticipantName );
                stream.WriteLine( "technology = c#" );
            }

        }

        /// <summary>
        /// write exception to console.error
        /// includes inner exception and data
        /// </summary>
        /// <param name="e">exception that should be shown</param>
        /// <param name="codeSegment">segment where the exception was caught</param>
        public static void ShowException( Exception e, string codeSegment )
        {
            KContract.Requires( e != null, "e is mandatory but is null" );
            KContract.Requires( ! string.IsNullOrWhiteSpace(codeSegment), "codeSegment is mandatory but is null or whitespace" );

            Console.Out.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
            Console.Out.WriteLine(  codeSegment );
            Console.Out.WriteLine( "[{0}]: {1}", e.GetType( ).Name, e.Message );

            for ( Exception inner = e.InnerException
                ; inner != null
                ; inner = inner.InnerException )
            {
                System.Console.WriteLine( ">>[{0}] {1}"
                                                , inner.GetType( ).Name
                                                , inner.Message
                                            );
            }


            if ( e.Data != null && e.Data.Count > 0 )
            {
                Console.Error.WriteLine( "------------------------------------------------" );
                Console.Error.WriteLine( "Data in exception:" );
                foreach( KeyValuePair<string, string> elem in e.Data )
                {
                    Console.Error.WriteLine( "[{0}] : '{1}'", elem.Key, elem.Value );
                }
            }
            Console.Out.WriteLine( "------------------------------------------------" );
            Console.Out.WriteLine( e.StackTrace );
            Console.Out.WriteLine( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" );
        }
    }
}
