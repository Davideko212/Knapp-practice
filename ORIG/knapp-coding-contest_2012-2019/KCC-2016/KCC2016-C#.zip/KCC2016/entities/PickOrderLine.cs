﻿using com.knapp.KCC2016.util;

namespace com.knapp.KCC2016.entities
{
    /// <summary>
    /// Represents a product that must be picked for a PickOrder
    /// </summary>
    public class PickOrderLine
    {
        /// <summary>
        /// The id of the order this line belongs to
        /// </summary>
        public string OrderId { get; private set; }

        /// <summary>
        /// The code of the product to pack
        /// </summary>
        public string ProductCode { get; private set; }

        /// <summary>
        /// The number of items
        /// </summary>
        public uint Quantity { get; private set; }

        /// <summary>
        /// Stringified partial representation of this instance
        /// </summary>
        /// <returns></returns>
        public override string ToString( )
        {
            return string.Format("{0}: {1}pcs", ProductCode, Quantity);
        }

        /// <summary>
        /// Create a PickOrderLine for the given product
        /// 
        /// 
        /// 
        /// </summary>
        /// <param name="dataAsArray">string array containing the data fromt he csv file</param>
        public PickOrderLine( string[ ] dataAsArray )
        {
            KContract.Requires( dataAsArray.Length == 3, "data array must contain three elemetns for PickOrderLine" );
            KContract.Requires( !string.IsNullOrWhiteSpace( dataAsArray[ 0 ] ), "orderId required but is null or whitespace only" );
            KContract.Requires( !string.IsNullOrWhiteSpace( dataAsArray[ 1 ] ), "productCode required but is null or whitespace only" );
            KContract.Requires( !string.IsNullOrWhiteSpace( dataAsArray[ 2 ] ), "quantity required but is null or whitespace only" );

            this.OrderId = dataAsArray[ 0 ].Trim( );
            this.ProductCode = dataAsArray[ 1 ].Trim( );
            this.Quantity = uint.Parse( dataAsArray[ 2 ] );
        }
    }
}
