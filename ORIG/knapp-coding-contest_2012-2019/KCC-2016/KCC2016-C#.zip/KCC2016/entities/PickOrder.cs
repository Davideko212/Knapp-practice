﻿using com.knapp.KCC2016.util;
using System.Collections.Generic;
using System.Linq;
using System;

namespace com.knapp.KCC2016.entities
{
    /// <summary>
    /// A PickOrder (Kommissionierauftrag) which should be packed in the warehouse
    /// with the current assignment of products
    /// </summary>
    public class PickOrder
    {

        /// <summary>
        /// Get the unique Id for this order
        /// </summary>
        public string OrderId { get; private set; }

        public int LineCount
        {
            get
            {
                return orderLines.Count;
            }
        }

        private readonly List<PickOrderLine> orderLines = new List<PickOrderLine>( );

        /// <summary>
        /// Create a PickOrder instance with the given id
        /// </summary>
        /// <param name="orderId">OrderId to use</param>
        public PickOrder( string orderId )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( orderId ), "orderId mandatory but is null" );

            this.OrderId = orderId;
        }

        /// <summary>
        /// Get iterator for the PickOrderLines in this order
        /// </summary>
        /// <returns>iterator for the pickorderlines</returns>
        public IReadOnlyCollection<PickOrderLine> GetPickOrderLines()
        {
                return orderLines.AsReadOnly( );
        }

        /// <summary>
        /// Add a product to this order
        /// Creates a new pickOrderLine for this product
        /// </summary>
        /// <param name="pickOrderLine">the pickOrderLine to add</param>
        public void Add( PickOrderLine pickOrderLine )
        {
            KContract.Requires( pickOrderLine != null, "pickOrderLine mandatory but is null or whitespace" );

            orderLines.Add( pickOrderLine );
        }

        /// <summary>
        /// Whether a certain product is already in the order
        /// </summary>
        /// <param name="productCode">code of the product to check</param>
        /// <returns>true when product is found in this order, false in all other cases</returns>
        public bool ContainsProduct(string productCode)
        {
            return !string.IsNullOrWhiteSpace(productCode) && orderLines.Any(x => x.ProductCode == productCode);
        }

    }
}
