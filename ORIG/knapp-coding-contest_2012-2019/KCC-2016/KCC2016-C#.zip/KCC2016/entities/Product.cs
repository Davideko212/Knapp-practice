﻿using com.knapp.KCC2016.util;
using System;

namespace com.knapp.KCC2016.entities
{
    /// <summary>
    /// A product that is handled in a warehouse
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Unique code of this product
        /// </summary>
        public string Code { get; private set; }

        /// <summary>
        /// The maximum number of items that can be stored in a pick location
        /// </summary>
        public uint MaxLocationQuantity { get; private set; }

        /// <summary>
        /// Flag wether this item is a fast mover
        /// </summary>
        public bool FastMover { get; set; }

        /// <summary>
        /// Get stringified representation of this instance
        /// </summary>
        /// <returns>strign with infos for this instance</returns>
        public override string ToString( )
        {
            return "Item " + Code;
        }

        /// <summary>
        /// Create a product from the given data
        /// </summary>
        /// <param name="dataAsArray"></param>
        public Product( string[] dataAsArray )
        {
            KContract.Requires( dataAsArray != null, "dataAsArray mandatory but is null" );
            KContract.Requires( dataAsArray.Length == 3, "dataAsArray must contain 4 elements"  );
            KContract.Requires<ArgumentException>( !string.IsNullOrWhiteSpace( dataAsArray[ 0 ] ), "Code must not be null @ offset 0" );

            Code = dataAsArray[ 0 ].Trim( );
            MaxLocationQuantity = uint.Parse( dataAsArray[ 1 ] );
            FastMover = bool.Parse( dataAsArray[ 2 ] );
        }

        /// <summary>
        /// Equality operation
        /// </summary>
        /// <param name="obj">object to compare with</param>
        /// <returns>true when obj is a Product and has the same code, false in any other case</returns>
        public override bool Equals( object obj )
        {
            Product other = obj as Product;

            return other != null
                && this.Code == other.Code
                ;
        }

        /// <summary>
        /// GetHashCode method
        /// since Equals is defined
        /// </summary>
        /// <returns>the product code</returns>
        public override int GetHashCode( )
        {
            return Code.GetHashCode( );
        }


        /// <summary>
        /// Serialize this instance to a string
        /// </summary>
        /// <returns></returns>
        public string[] ToArray()
        {
            return new string[ ] { Code, MaxLocationQuantity.ToString( ), FastMover.ToString( ) };
        }
    }
}
