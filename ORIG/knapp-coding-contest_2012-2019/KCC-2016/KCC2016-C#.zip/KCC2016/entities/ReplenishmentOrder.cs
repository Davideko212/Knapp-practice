﻿using com.knapp.KCC2016.util;
using System.Collections.Generic;

namespace com.knapp.KCC2016.entities
{
    public class ReplenishmentOrder
    {
        /// <summary>
        /// internal field to create a 'unique' order id
        /// </summary>
        private static int nextOrderId = 1;

        /// <summary>
        /// Id of this order
        /// </summary>
        public string OrderId { get; private set; }

        /// <summary>
        /// the code of the product that should be replenished
        /// </summary>
        public string ReplenishedProductCode { get; private set; }

        /// <summary>
        /// the location to which the replenishment should go
        /// </summary>
        public string ReplenishedLocation { get; private set; }

        /// <summary>
        /// the number of pieces to replenis
        /// </summary>
        public uint ReplenishedQuantity { get; private set; }

        /// <summary>
        /// Create a new replenishment order and assign a generated id
        /// </summary>
        public ReplenishmentOrder( Product product, Location location, uint quantity )
        {
            KContract.Requires( product != null, "product mandatory but is missing" );
            KContract.Requires( location != null, "location mandatory but is missing" );

            OrderId = string.Format( "ReplenOrder_{0}", nextOrderId++ );

            ReplenishedProductCode = product.Code;
            ReplenishedLocation = location.Code;
            ReplenishedQuantity = quantity;
        }
    }
}
