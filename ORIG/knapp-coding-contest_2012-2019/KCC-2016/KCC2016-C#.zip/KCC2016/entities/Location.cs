﻿using com.knapp.KCC2016.util;
using System;

namespace com.knapp.KCC2016.entities
{
    /// <summary>
    /// Represents a location within a shelf that can hold one single product
    /// </summary>
    public class Location
    {
        /// <summary>
        /// Get the unique code of the location
        /// </summary>
        public string Code { get; private set; }

        /// <summary>
        /// The currently assigned product
        /// </summary>
        public Product AssignedProduct { get; set; }

        /// <summary>
        /// The current quantity that is physically available at this location
        /// </summary>
        public uint QuantityOnHand { get; set; }

        /// <summary>
        /// Construct a location an set it's unique code
        /// </summary>
        /// <param name="code"></param>
        public Location( string code )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( code ), "code required but is null or whitespace only" );

            this.Code = code;
        }

        /// <summary>
        /// Construct the zone from the given data
        /// </summary>
        /// <param name="dataAsArray">data to construct this instance from</param>
        public Location( string[ ] dataAsArray )
        {
            KContract.Requires( dataAsArray != null, "dataAsArray mandatory but is null" );
            KContract.Requires( dataAsArray.Length == 3, "location record must have 3 fields" );
            KContract.Requires( !string.IsNullOrWhiteSpace( dataAsArray[ 0 ] ), "zone name must be set" );
            KContract.Requires( !string.IsNullOrWhiteSpace( dataAsArray[ 2 ] ), "location code must be set" );

            this.Code = dataAsArray[ 2 ];

            AssignedProduct = null;
            QuantityOnHand = 0;
        }

        /// <summary>
        /// Get a stringified representation of the object
        /// </summary>
        /// <returns></returns>
        public override string ToString( )
        {
            if ( AssignedProduct != null  )
            {
                return string.Format( "[{0}] holds '{1}', pcs: {2}"
                                        , Code
                                        , AssignedProduct.Code
                                        , QuantityOnHand
                                        );
            }
            else
            {
                return string.Format( "[{0}] is unassigned"
                                        , Code
                                        );
            }
        }
    }
}
