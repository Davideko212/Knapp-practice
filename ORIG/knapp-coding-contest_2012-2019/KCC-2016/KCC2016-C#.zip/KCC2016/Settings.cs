﻿using com.knapp.KCC2016.util;

namespace com.knapp.KCC2016
{
    /// <summary>
    /// class containing settings for the program
    /// 
    /// DO NOT MODIFY THE SETTINGS
    /// 
    /// </summary>
    public sealed class Settings
    {
        /// <summary>
        /// Directory for the input files
        /// </summary>
        public const string DataPath = @"input";

        /// <summary>
        /// Directory where the output will be written
        /// </summary>
        public const string OutputPath = @"";

        /// <summary>
        /// Name of the results file
        /// </summary>
        public const string outReplenFilename = @"replenishmentOrders.csv";

        /// <summary>
        /// Name of the properties file
        /// </summary>
        public const string outPropertyFilename = @"KCC2016.properties";

        /// <summary>
        /// Name of the zip-file that is generated
        /// </summary>
        public const string outZipFilename = @"upload2016.zip";

        /// <summary>
        /// The max. number of pick orders that will be picked during one cycle
        /// </summary>
        public const int PICKS_PER_CYCLE = 1;

        /// <summary>
        /// The number of cycles that can be run
        /// After that, the work is terminated
        /// </summary>
        public const int MAX_ALLOWED_CYCLES = 20000;

        private Settings( )
        {}
    }
}
