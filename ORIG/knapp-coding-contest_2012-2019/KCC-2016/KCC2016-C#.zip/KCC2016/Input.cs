﻿using com.knapp.KCC2016.data;

namespace com.knapp.KCC2016
{
    /// <summary>
    /// Container class for all input into the solution
    /// </summary>
    public class Input
    {
        /// <summary>
        /// Container for all locations in the warehouse
        /// </summary>
        public LocationCollection LocationCollection { get; private set; }

        /// <summary>
        /// Container for all products that have to be slotted (assigned to locations)
        /// </summary>
        public ProductCollection ProductCollection { get; private set; }


        /// <summary>
        /// Container for all pickOrders that will be picked out of the warehouse
        /// You do not need to implement picking, this will be done by KNAPP during
        /// evaluation
        /// </summary>
        public PickOrderCollection PickOrderCollection { get; private set; }

        /// <summary>
        /// Create from outside only via CreateFromCsv
        /// </summary>
        private Input( )
        { }

        /// <summary>
        /// Load all input data from the csv files and create instance (and composite instances)
        /// </summary>
        /// <returns>a newly created ínstance of the inout</returns>
        public static Input CreateFromCsv()
        {
            Input input = new Input();

            input.LocationCollection = LocationCollection.CreateFromCsv( System.IO.Path.Combine( Settings.DataPath, @"locations.csv" ) );

            input.ProductCollection = ProductCollection.CreateFromCsv( System.IO.Path.Combine( Settings.DataPath, @"products.csv" ) );

            input.PickOrderCollection = PickOrderCollection.CreateFromCsv( System.IO.Path.Combine( Settings.DataPath, @"pickorders.csv" ) );

            return input;
        }
    }
}
