﻿using System.IO;
using System.IO.Compression;

namespace com.knapp.KCC2016.util
{
    /// <summary>
    /// Helper class to create zip for upload
    /// </summary>
    public static class PrepareUpload
    {
        /// <summary>
        /// 
        /// Create uploadable zip file
        /// 
        /// </summary>
        public static void CreateZipFile()
        {
            string resultsFile = Path.Combine( Settings.OutputPath, Settings.outReplenFilename );
            string propertiesFile = Path.Combine( Settings.OutputPath, Settings.outPropertyFilename );
            string zipFile = Path.Combine( Settings.OutputPath, Settings.outZipFilename );

            if ( File.Exists( zipFile ) )
            {
                File.Delete( zipFile );
            }

            using ( ZipArchive archive = ZipFile.Open( zipFile, ZipArchiveMode.Create ) )
            {
                archive.CreateEntryFromFile( resultsFile, Settings.outReplenFilename );
                archive.CreateEntryFromFile( propertiesFile, Settings.outPropertyFilename );
            }
        }
    }
}
