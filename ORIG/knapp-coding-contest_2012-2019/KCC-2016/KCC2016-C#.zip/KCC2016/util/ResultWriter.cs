﻿using com.knapp.KCC2016.entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.knapp.KCC2016.util
{
    /// <summary>
    /// Write for result file
    /// 
    /// Should not be modified
    /// 
    /// </summary>
    public class ResultWriter : IDisposable
    {
        private readonly StreamWriter resultFileWriter;

        /// <summary>
        /// Create a result writer that will write to the given file
        /// An existing file is deleted
        /// </summary>
        /// <param name="filename"></param>
        public ResultWriter( string filename )
        {
            KContract.Requires( ! string.IsNullOrWhiteSpace( filename ), "filename required but is null or whitespace"  );

            if ( File.Exists( filename ) )
            {
                File.Delete( filename );
            }

            resultFileWriter = new StreamWriter( filename );
        }

        /// <summary>
        /// Write the results within the collection into the file
        /// </summary>
        /// <param name="result">the list with results as Tuples (tick, replenOrder)</param>
        public void Write( List<Tuple<int,ReplenishmentOrder>> result )
        {
            KContract.Requires( result != null, "result mandatory but is required" );

            foreach( var row in result )
            {
                WriteLine( row.Item1, row.Item2 );
            }
        }

        /// <summary>
        /// Write the result of orderStart into the result file
        /// Format for file: HH:MM;OrderNr;SubOrderNr;
        /// </summary>
        /// <param name="currentTick">the timenumber of the current cycle</param>
        /// <param name="replenishmentOrder">replenishmentorder to execute</param>
        private void WriteLine( int currentTick, ReplenishmentOrder replenishmentOrder )
        {
            KContract.Requires( null != replenishmentOrder, "replenishmentOrder required but is null" );

            string resultLine = string.Format( "{0};{1};{2};{3};{4}"
                   , currentTick
                   , replenishmentOrder.OrderId
                   , replenishmentOrder.ReplenishedProductCode
                   , replenishmentOrder.ReplenishedLocation
                   , replenishmentOrder.ReplenishedQuantity
                   );

            resultFileWriter.WriteLine( resultLine );
        }


        /// <summary>
        /// Dispose
        /// closes resultFilewriter
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose( bool disposing )
        {
            if ( disposing )
            {
                resultFileWriter.Flush( );
                resultFileWriter.Close( );
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose( )
        {
            Dispose( true );
        }

    }
}
