﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using com.knapp.KCC2016.data;
using com.knapp.KCC2016.entities;
using com.knapp.KCC2016.solution;

namespace com.knapp.KCC2016.util
{
    public class Scheduler : IDisposable
    {
        private readonly ProductCollection productCollection;
        private readonly PickOrderCollection pickOrderCollection;
        private readonly LocationCollection locationCollection;


        /// <summary>
        /// Construct a framework for the simulation of the day
        /// </summary>
        /// <param name="productCollection">products for the day</param>
        /// <param name="pickOrderCollection">orders for the day</param>
        /// <param name="pickZone">zone with all locations</param>
        /// <param name="resultFilename">name of the file for the result</param>
        public Scheduler( ProductCollection productCollection
                           , PickOrderCollection pickOrderCollection 
                           , LocationCollection locationCollection
                        )
        {
            KContract.Requires( productCollection != null, "productCollection required but is null" );
            KContract.Requires( pickOrderCollection != null, "pickOrderCollection required but is null" );
            KContract.Requires( locationCollection != null, "locationCollection required but is null" );

            this.productCollection = productCollection;
            this.pickOrderCollection = pickOrderCollection;
            this.locationCollection = locationCollection;
        }

        /// <summary>
        /// Main simulation loop
        /// 
        /// It performs the following actions in this sequence:
        /// (1) call GetNextReplenishmentOrder to get the replenishment move from your solution
        /// (2) executes the replenishment order and adds the stock to the locations
        /// (3) picks all orders that have sufficient stock on the locations in
        ///      in the sequence as the orders are listed in the pickOrderCollection
        /// (3.1) Remove all stock picked from the locations
        /// (4) calls HandlePick in your solution with the order that has been picked
        /// 
        /// Note: you may modify this method although it should not be necessary
        /// 
        /// </summary>
        /// <param name="solution"></param>
        public List<Tuple<int, ReplenishmentOrder>> Run( Solution solution )
        {
            KContract.Requires(null != solution, "solution required but is null");

            List<Tuple<int, ReplenishmentOrder>> results = new List<Tuple<int, ReplenishmentOrder>>( );

            Console.Out.WriteLine("### Starting work...");

            int currentTick = 0;
            while( pickOrderCollection.Count > 0 
                && currentTick < Settings.MAX_ALLOWED_CYCLES )
            {
                ReplenishmentOrder replenOrder;
                try
                {
                    replenOrder = solution.GetNextReplenishmentOrder( );
                }
                catch (Exception e)
                {
                    Program.ShowException(e, "USER-Code");
                    throw;
                }

                try
                {
                    if (replenOrder != null)
                    {
                        results.Add( new Tuple<int, ReplenishmentOrder>( currentTick, replenOrder ) );
                        if ( !RefillLocations(replenOrder, currentTick ) )
                        {
                            Console.Out.WriteLine("### Ending because of error during replenishment.");
                            break;
                        }
                    }

                    List<PickOrder> pickedOrders = new List<PickOrder>( );
                    TryPickOrders( currentTick, pickedOrders );

                    solution.HandlePickedOrders( pickedOrders.AsReadOnly( ) );

                    if ( pickOrderCollection.LineCount == 0 )
                    {
                        Console.Out.WriteLine( "### Congratulations, all pick orders done!" );
                        break;
                    }
                }
                catch (Exception e)
                {
                    Console.Error.WriteLine("!!! Exception in GetNextReplenOrder @ {0}", currentTick );
                    Console.Error.WriteLine("   {0}", e.GetType().FullName);
                    Console.Error.WriteLine("   {0}", e.Message);
                    Console.Error.WriteLine("   {0}", e.StackTrace);

                    throw;
                }

                ++currentTick;
            }

            Console.Out.WriteLine("### Ending work @ {0}", currentTick );

            if ( pickOrderCollection.Count > 0 )
            {
                Console.Out.WriteLine( "### Remaining work: {0} orders with {1} lines"
                            , pickOrderCollection.Count
                            , pickOrderCollection.LineCount );
            }

            return results;
        }

        /// <summary>
        /// Execute a replenishment order
        /// add the quantities within the replenishment order to the locations specified
        /// 
        /// Note: You may modify this method, although it should not be necessary
        /// 
        /// </summary>
        /// <param name="replenishmentOrder">the order to execute</param>
        /// <param name="currentTick">current cycle number</param>
        /// <returns>always true</returns>
        private bool RefillLocations(ReplenishmentOrder replenishmentOrder, int currentTick )
        {
            Location target = locationCollection.GetLocation(replenishmentOrder.ReplenishedLocation);

            if ( target != null )
            {
                Product product = GetProduct( replenishmentOrder.ReplenishedProductCode );

                if ( null == product )
                {
                    throw new InvalidOperationException( "Trying to assign an unknown product: " + replenishmentOrder.ReplenishedProductCode );
                }

                if ( target.AssignedProduct != null
                    && !target.AssignedProduct.Code.Equals( replenishmentOrder.ReplenishedProductCode )
                    && target.QuantityOnHand > 0
                    )
                {
                    throw new InvalidOperationException( "Already a different product at the location: " + target.AssignedProduct.Code );
                }

                if ( target.QuantityOnHand + replenishmentOrder.ReplenishedQuantity > product.MaxLocationQuantity )
                {
                    throw new InvalidOperationException( "Exceeded maximum location amount" );
                }

                target.AssignedProduct = product;
                target.QuantityOnHand += replenishmentOrder.ReplenishedQuantity;
            }
            else
            {
                Console.WriteLine( "ERROR @ {0}: target location '{1}' not found for order {2}: "
                                            , currentTick
                                            , replenishmentOrder.ReplenishedLocation
                                            , replenishmentOrder.OrderId
                                        );
                return false;
            }
         
            return true;
        }

        /// <summary>
        /// Pick all orders the have sufficient stock on locations
        /// The orders are searched in the sequence in which they are listed in the pickOrderCollection
        /// 
        /// Note: You may modify this method, although it should not be necessary
        /// Changes will only impact your local code, the evaluation code on the server (determining your rating)
        /// will not be affected.
        /// 
        /// </summary>
        /// <param name="pickedOrders">list for the orders that have been picke in this cycle</param>
        /// <returns>number of orders that have been picked</returns>
        private int TryPickOrders( int currentTick, List<PickOrder> pickedOrders )
        {
            // prepare a list of products with stock on hand and remember the locations
            var fourWall = locationCollection.GetLocations().Where( l => l.QuantityOnHand > 0 )
                .GroupBy( l => l.AssignedProduct.Code )
                .Select( g => new { ProductCode = g.Key, Locations = g.OrderBy( x => x.QuantityOnHand )
                                                                        .ThenBy( (x) => x.Code )
                                                                        .ToList() } )
                .ToDictionary( x => x.ProductCode )
                ;

            // try to pick an order
            int numberOfPickedOrders = 0;
            foreach( var order in pickOrderCollection.GetPickOrders() )
            {

                bool isPickable = true;

                foreach (var line in order.GetPickOrderLines())
                {
                    if (!fourWall.ContainsKey(line.ProductCode))
                    {
                        isPickable = false;
                        break;
                    }
                    long onHand = fourWall[line.ProductCode].Locations.Sum(x => x.QuantityOnHand);

                    if (onHand < line.Quantity)
                    {
                        isPickable = false;
                        break;
                    }
                }

                if (isPickable)
                {
                    foreach (var line in order.GetPickOrderLines())
                    {
                        uint neededQuantity = line.Quantity;
                        foreach (var location in fourWall[line.ProductCode].Locations)
                        {
                            if (location.QuantityOnHand >= neededQuantity )
                            {
                                //(remaining) line can be picked from one location
                                location.QuantityOnHand -= neededQuantity;

                                if ( location.QuantityOnHand == 0)
                                {
                                    location.AssignedProduct = null;
                                }

                                break;
                            }
                            else
                            {
                                //pick all items from location
                                uint t = location.QuantityOnHand;
                                location.QuantityOnHand = 0;
                                location.AssignedProduct = null;

                                neededQuantity -= t;
                            }
                        }
                    }
                    pickedOrders.Add( order );
                    pickOrderCollection.Remove( order );

                    ++numberOfPickedOrders;
                    if ( numberOfPickedOrders >= Settings.PICKS_PER_CYCLE )
                    {
                        break;
                    }
                }
            }

            Console.Out.WriteLine( "[Cyle {0}] Picked {1} orders, orders left: {2}"
                , currentTick
                , numberOfPickedOrders
                , pickOrderCollection.Count
                );

            return numberOfPickedOrders;
        }


        /// <summary>
        /// Helper fucntion to get propduct by id
        /// </summary>
        /// <param name="productCode"></param>
        /// <returns></returns>
        private Product GetProduct(string productCode)
        {
            return productCollection.GetProduct(productCode);
        }

        /// <summary>
        /// Dispose
        /// closes resultFilewriter
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        { }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
        }
    }
}