﻿using com.knapp.KCC2016.entities;
using System.Collections.Generic;
using com.knapp.KCC2016.util;

namespace com.knapp.KCC2016.data
{
    public class ProductCollection
    {
        private readonly Dictionary<string, Product> products = new Dictionary<string, Product>( );

        /// <summary>
        /// A product collection can only be created using CreateFromCsv
        /// </summary>
        private ProductCollection()
        { }

        /// <summary>
        /// Get the total number of products currently in this collection
        /// </summary>
        public int Count
        {
            get
            {
                return products.Count;
            }
        }

        /// <summary>
        /// Get the product with the given code
        /// </summary>
        /// <param name="productCode">code of the product to return</param>
        /// <returns>product with the given code if it was found in the collection; null otherwise</returns>
        public Product GetProduct( string productCode )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( productCode ), "productCode mandatory but is null or whitespace" );

            if ( products.ContainsKey( productCode ) )
            {
                return products[ productCode ];
            }

            return null;
        }

        /// <summary>
        /// Get an enumerator for all products in the collection
        /// </summary>
        /// <returns>an enumerator for all products</returns>
        public IEnumerable<Product> GetProducts()
        {
            return products.Values;
        }

        /// <summary>
        /// Create a ProductColleciton and load products from given csv
        /// </summary>
        /// <param name="fullFilename">full path of th csv</param>
        /// <returns>newly created instance</returns>
        public static ProductCollection CreateFromCsv( string fullFilename )
        {
            KContract.Requires( ! string.IsNullOrWhiteSpace( fullFilename  ), "fullFilename mandatory but is null or whitespace");

            ProductCollection productCollection = new ProductCollection( );

            foreach ( Product product in CsvReader.ReadCsvFile<Product>( fullFilename ) )
            {
                productCollection.Add( product );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} products", productCollection.Count );

            return productCollection;
        }

        /// <summary>
        /// Add a product to the collection
        /// </summary>
        /// <param name="product">the product to add</param>
        private void Add( Product product )
        {
            KContract.Requires( product != null, "product mandatory but is null");

            products.Add( product.Code, product );
        }
    }
}
