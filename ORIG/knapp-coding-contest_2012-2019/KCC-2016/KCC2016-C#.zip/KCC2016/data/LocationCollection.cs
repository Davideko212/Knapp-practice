﻿using com.knapp.KCC2016.entities;
using com.knapp.KCC2016.util;
using System.Collections.Generic;

namespace com.knapp.KCC2016.data
{
    public class LocationCollection
    {
        private readonly Dictionary<string, Location> locations = new Dictionary<string, Location>( );

        /// <summary>
        /// Get the number of locations currently available
        /// </summary>
        public int Count
        {
            get
            {
                return locations.Count;
            }
        }

        protected LocationCollection()
        {}

        /// <summary>
        /// Get an enumerator for all locations
        /// </summary>
        /// <returns>enumerator for all locations</returns>
        public IEnumerable<Location> GetLocations()
        {
            return locations.Values;
        }

        /// <summary>
        /// Get the location with the given code
        /// </summary>
        /// <param name="code">code of the location to return</param>
        /// <returns>location with the given code, null otherwise</returns>
        public Location GetLocation( string code )
        {
            KContract.Requires( code != null, "code required but is null" );

            if ( locations.ContainsKey( code ) )
            {
                return locations[ code ];
            }

            return null;
        }

        /// <summary>
        /// Create a ProductColleciton and load products from given csv
        /// </summary>
        /// <param name="fullFilename"></param>
        /// <returns>newly created instance</returns>
        public static LocationCollection CreateFromCsv( string fullFilename )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "fullFilename mandatory but is null or whitespace" );

            LocationCollection instance = new LocationCollection( );


            foreach ( Location product in CsvReader.ReadCsvFile<Location>( fullFilename ) )
            {
                instance.Add( product );
            }
            System.Console.Out.WriteLine( "+++ loaded: {0} products", instance.Count );


            return instance;
        }

        /// <summary>
        /// Add a location to the collection
        /// </summary>
        /// <param name="location"></param>
        private void Add( Location location )
        {
            locations.Add( location.Code, location );
        }
    }
}
