﻿using com.knapp.KCC2016.entities;
using System;
using System.Collections.Generic;
using com.knapp.KCC2016.util;
using System.Linq;

namespace com.knapp.KCC2016.data
{
    public class PickOrderCollection
    {
        private readonly Dictionary<string, PickOrder> orders = new Dictionary<string, PickOrder>( );
        private readonly List<PickOrderLine> orderLines = new List<PickOrderLine>();

        private readonly Dictionary<string, int> cacheNeededQuantity = new Dictionary<string, int>( );

        /// <summary>
        /// PickOrderCollection can only be created via CreatFromCsv
        /// </summary>
        private PickOrderCollection( )
        { }


        /// <summary>
        /// Get a specific pickOrder
        /// </summary>
        /// <param name="orderId"> id of the pickorder to retrieve</param>
        /// <returns>the specified pickorder or null if it could not be found</returns>
        public PickOrder GetPickOrder( string orderId )
        {
            KContract.Requires<ArgumentNullException>( orderId != null, "orderId required but is null" );

            return orders.ContainsKey( orderId ) ? orders[ orderId ] : null;
        }

        /// <summary>
        /// Get an enumerator for all pickOrders
        /// </summary>
        /// <returns>the enumerator for all PickOrder</returns>
        public IEnumerable<PickOrder> GetPickOrders()
        {
            return orders.Values;
        }

        /// <summary>
        /// The total number of pickOrders in this collection
        /// </summary>
        public int Count
        {
            get
            {
                return orders.Count;
            }
        }

        /// <summary>
        /// The total number of lines for all orders
        /// </summary>
        public int LineCount
        {
            get
            {
                return orderLines.Count;
            }
        }


        /// <summary>
        /// Retrieve the quantity that is currently needed for the product spcified 
        /// for all still open orders
        /// </summary>
        /// <param name="productCode">code of the product to get the quantity for</param>
        /// <returns>needed pcs, 0 in all other cases (also unkown items)</returns>
        public int GetCurrentNeededQuantity( string productCode )
        {
            int qty = 0;

            cacheNeededQuantity.TryGetValue( productCode, out qty );

            return qty;
        }

        /// <summary>
        /// Get all the currently pending orderlines
        /// 
        /// Helper property to get the orderlines of all orders, same data as in PickOrder.Lines
        /// 
        /// </summary>
        public IReadOnlyList<PickOrderLine> GetPickOrderLines( )
        {
            return orderLines.AsReadOnly( );
        }

        public void Remove( PickOrder order )
        {
            KContract.Requires( order != null, "orderId required but is null");

            orders.Remove(order.OrderId);

            orderLines.RemoveAll( x => x.OrderId == order.OrderId );

            DecreaseNeededQuantity( order );
        }

        /// <summary>
        /// Load the PickOrders from the csv and create the objects
        /// </summary>
        /// <param name="fullFilename">full path of the csv</param>
        /// <returns>new PickOrderCollection with all PickOrders and their PickOrderLines from the csv</returns>
        public static PickOrderCollection CreateFromCsv( string fullFilename )
        {
            KContract.Requires( !string.IsNullOrWhiteSpace( fullFilename ), "filename mandatory but is null or whitespace only" );

            PickOrderCollection orderCollection = new PickOrderCollection( );

            int lineCount = 0;
            foreach ( PickOrderLine pickOrderLine in CsvReader.ReadCsvFile<PickOrderLine>( fullFilename ) )
            {
                ++lineCount;

                PickOrder order;


                if ( orderCollection.orders.ContainsKey( pickOrderLine.OrderId ) )
                {
                    order = orderCollection.orders[ pickOrderLine.OrderId ];
                }
                else
                {
                    order = new PickOrder( pickOrderLine.OrderId );
                    orderCollection.orders.Add( order.OrderId, order );
                }

                order.Add( pickOrderLine );
                orderCollection.orderLines.Add( pickOrderLine );
            }

            Console.Out.WriteLine( "+++ loaded: {0} orders with {1} lines"
                                            , orderCollection.Count
                                            , lineCount
                                            );

            orderCollection.PrepareCacheNeededQuantity( );

            return orderCollection;
        }

        #region convenience function to keep cacheNeededQuantity up to date
        /// <summary>
        /// Sum up the needed quantity for a product and store it
        /// only called initially
        /// 
        /// Function used only internally to keep the product/ demand cache up to date
        /// 
        /// </summary>
        private void PrepareCacheNeededQuantity()
        {
            var q = orderLines.GroupBy( l => l.ProductCode )
                                .Select( g => new
                                {
                                    ProductCode = g.Key,
                                    NeededQuantity = g.Sum( x => x.Quantity )
                                }
                                );

            foreach( var row in q )
            {
                cacheNeededQuantity.Add( row.ProductCode, (int)row.NeededQuantity );
            }

        }

        /// <summary>
        /// decrease the cached needed quantity for an order
        ///
        /// Function used only internally to keep the product/ demand cache up to date
        /// 
        /// </summary>
        private void DecreaseNeededQuantity( PickOrder pickOrder )
        {
            foreach ( PickOrderLine pickOrderLine in pickOrder.GetPickOrderLines( ) )
            {
                if ( cacheNeededQuantity.ContainsKey( pickOrderLine.ProductCode ) )
                {
                    cacheNeededQuantity[ pickOrderLine.ProductCode ] -= (int)pickOrderLine.Quantity;
                }
            }
        }
        #endregion
    }
}
