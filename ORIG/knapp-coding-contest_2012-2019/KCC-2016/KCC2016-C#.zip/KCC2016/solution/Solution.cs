﻿using System;
using System.Linq;
using System.Collections.Generic;

using com.knapp.KCC2016.data;
using com.knapp.KCC2016.entities;
using com.knapp.KCC2016.util;

namespace com.knapp.KCC2016.solution
{
    public class Solution
    {

        /// <summary>
        /// 
        /// Your name
        /// Please set in constructor 
        /// </summary>
        public string ParticipantName { get; private set; }

        /// <summary>
        /// 
        /// The Id of your institute - please refer to the handout
        /// Please set in constructor
        /// </summary>
        public string InstituteId { get; private set; }

        /// <summary>
        /// local reference to the global location collection
        /// </summary>
        private readonly LocationCollection locationCollection;

        /// <summary>
        /// local reference to the global product collection
        /// </summary>
        private readonly ProductCollection productCollection;

        /// <summary>
        /// local reference to the global collection with unfulfilled pick-orders
        /// 
        /// Note: the pickOrderCollection is always up to date when GetNextReplenishmentOrder is called
        /// 
        /// </summary>
        private readonly PickOrderCollection pickOrderCollection;





        /// <summary>
        /// Create the solution instance 
        /// 
        /// Do all your preparations here
        /// 
        /// </summary>
        public Solution(Input input)
        {
            KContract.Requires( input != null, "input required but is null" );

            KContract.Requires( input.LocationCollection != null, "input.LocationCollection required but is null" );
            KContract.Requires( input.LocationCollection.Count > 0, "input.LoctionCollection empty" );

            KContract.Requires( input.ProductCollection != null, "input.ProductCollection required but is null" );
            KContract.Requires( input.ProductCollection.Count > 0, "input.ProductCollection is empty" );

            KContract.Requires( input.PickOrderCollection != null, "input.PickOrderCollection required but is null" );
            KContract.Requires( input.PickOrderCollection.Count > 0, "input.PickorderCollection is empty" );

            locationCollection = input.LocationCollection;
            productCollection = input.ProductCollection;
            pickOrderCollection = input.PickOrderCollection;

            //Your code goes here
            //TODO
            ParticipantName = "";

            //TODO
            InstituteId = "";

        }

        /// <summary>
        /// Return the next replenishmentOrder to execute.
        /// 
        /// YOUR CODE SHOULD GO HERE
        /// 
        /// </summary>
        /// <returns>the next replenishment move for the caller to execute or null</returns>
        public ReplenishmentOrder GetNextReplenishmentOrder()
        {
            //TODO: add your code here to select the next (best) replen move
            //TODO: and return it to the caller
            //
            //The caller (KNAPP code) executes the replenishment and performs the next possible pick
            //If no replenishment order should be executed in this timeframe, return null

            //Your code goes here

            throw new NotImplementedException( "Please  code now." );


            return null; //return your created ReplenishmentOrder, or null if u do not want to do anything in this frame
        }


        /// <summary>
        /// This function is called after all picks have been performed by the framework.
        /// If necessary, you can handle it.
        /// Note: the pickOrderCollection is also updated and always reflects the current state
        /// Which means, the pick-orders in pickedOrders are no longer contained in the pickOrderCollection
        /// </summary>
        /// <param name="pickedOrders">read-only collection with the orders that have been picked</param>
        public void HandlePickedOrders( IReadOnlyCollection<PickOrder> pickedOrders )
        {

            //Your code goes here - if needed
        }
    }
}
